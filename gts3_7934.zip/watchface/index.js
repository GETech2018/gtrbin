
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$date$_$img_date = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$date$_$img_date = ''
        let idle$_$analog_clock$_$time_pointer = ''


        //dynamic modify end

        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
            "anim_rate": 'linear',
            "anim_duration": animDuration,
            "anim_from": 0,
            "anim_to": 360,
            "repeat_count": 1,
            "anim_fps": 25,
            "anim_key": "angle",
            "anim_status": 1,
        }
        /**
         * 在合适的层级调用此方法即可
         */
        function setSec() {
            if (now == null) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            var screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
                stopSecAnim();
            } else {
                secondPic = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    pos_x: 390 / 2 - 15,
                    pos_y: 450 / 2 - 181,
                    center_x: 195,
                    center_y: 225,
                    src:  "21.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
            }
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {//划入表盘
                    console.log('ui resume');
                    if (timer_sec_anim != null && timer_sec_anim != 0) return;
                    let duration = now.utc - lastTime;
                    if (duration < animDuration) {
                        duration = animDuration - duration;
                    } else {
                        duration = 0;
                    }
                    timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
                        lastTime = now.utc;
                        startSecAnim();
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim() {
            let sec = now.second * 6;
            secAnim["anim_from"] = sec;
            secAnim["anim_to"] = sec + animDuration * 6 / 1000;

            secondPic.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()中要调用一下这个方法
         */
        function stopSecAnim() {
            timer.stopTimer(timer_sec_anim);
            timer_sec_anim = 0;
        }


        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 305,
              day_sc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_tc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_en_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
  normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 290,
              week_en: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              week_tc: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              week_sc: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 33,
              hour_posY: 155,
              hour_path: '19.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 34,
              minute_posY: 173,
              minute_path: '20.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            setSec();
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '22.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 305,
              day_sc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_tc_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_en_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 290,
              week_en: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              week_tc: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              week_sc: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 33,
              hour_posY: 155,
              hour_path: '30.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 34,
              minute_posY: 173,
              minute_path: '31.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  