﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 222,
              font_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act-W_Font_12.png',
              unit_tc: 'Act-W_Font_12.png',
              unit_en: 'Act-W_Font_12.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 214,
              image_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 320,
              src: 'system_Blutoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 92,
              y: 322,
              src: 'system_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 138,
              image_array: ["m1.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 222,
              week_en: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_tc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_sc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 378,
              day_startY: 221,
              day_sc_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_tc_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_en_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 182,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 94,
              am_y: 360,
              am_sc_path: 'times_AM.png',
              am_en_path: 'times_AM.png',
              pm_x: 99,
              pm_y: 376,
              pm_sc_path: 'times_PM.png',
              pm_en_path: 'times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 338,
              hour_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_unit_sc: 'NULL.png',
              hour_unit_tc: 'NULL.png',
              hour_unit_en: 'NULL.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 338,
              minute_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 338,
              second_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Act-W_Font_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_01.png',
              hour_centerX: 240,
              hour_centerY: 241,
              hour_posX: 28,
              hour_posY: 159,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_02.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 37,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_03.png',
              second_centerX: 238,
              second_centerY: 239,
              second_posX: 21,
              second_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 11,
              y: 304,
              w: 114,
              h: 100,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 106,
              w: 100,
              h: 89,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: -6,
              w: 100,
              h: 140,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 302,
              w: 157,
              h: 106,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 199,
              w: 146,
              h: 87,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 207,
              w: 124,
              h: 78,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 71,
              w: 132,
              h: 123,
              src: 'A_Shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 222,
              font_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act-W_Font_12.png',
              unit_tc: 'Act-W_Font_12.png',
              unit_en: 'Act-W_Font_12.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 214,
              image_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 69,
              y: 320,
              src: 'system_Blutoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 92,
              y: 322,
              src: 'system_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 138,
              image_array: ["m1.png","m2.png","m3.png","m4.png","m5.png","m6.png","m7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 222,
              week_en: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_tc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              week_sc: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 378,
              day_startY: 221,
              day_sc_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_tc_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_en_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 182,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 94,
              am_y: 360,
              am_sc_path: 'times_AM.png',
              am_en_path: 'times_AM.png',
              pm_x: 99,
              pm_y: 376,
              pm_sc_path: 'times_PM.png',
              pm_en_path: 'times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 118,
              hour_startY: 338,
              hour_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_unit_sc: 'NULL.png',
              hour_unit_tc: 'NULL.png',
              hour_unit_en: 'NULL.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 338,
              minute_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 338,
              second_array: ["Layer 0.png","Layer 1.png","Layer 2.png","Layer 3.png","Layer 4.png","Layer 5.png","Layer 6.png","Layer 7.png","Layer 8.png","Layer 9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Act-W_Font_12.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_01.png',
              hour_centerX: 240,
              hour_centerY: 241,
              hour_posX: 28,
              hour_posY: 159,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_02.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 37,
              minute_posY: 232,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_03.png',
              second_centerX: 238,
              second_centerY: 239,
              second_posX: 21,
              second_posY: 202,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  