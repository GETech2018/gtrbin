﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 166,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 4,
              unit_sc: '017.png',
              unit_tc: '017.png',
              unit_en: '017.png',
              negative_image: '015.png',
              invalid_image: '015.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 170,
              src: '098.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 166,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 4,
              unit_sc: '017.png',
              unit_tc: '017.png',
              unit_en: '017.png',
              negative_image: '015.png',
              invalid_image: '015.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 170,
              src: '097.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 42,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 6,
              unit_sc: '058.png',
              unit_tc: '058.png',
              unit_en: '058.png',
              negative_image: '056.png',
              invalid_image: '015.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 29,
              image_array: ["068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png","088.png","089.png","090.png","091.png","092.png","093.png","094.png","095.png","096.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 168,
              src: '010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 120,
              src: '005.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 110,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 4,
              unit_sc: '113.png',
              unit_tc: '113.png',
              unit_en: '113.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 121,
              src: '006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 110,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 113,
              src: '010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 247,
              y: 0,
              src: '066.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 202,
              y: 3,
              src: '065.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 437,
              src: '062.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 439,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 274,
              y: 440,
              src: '113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 384,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 3,
              dot_image: '014.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 385,
              y: 384,
              src: '063.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 383,
              src: '061.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 384,
              font_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 272,
              y: 238,
              week_en: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png"],
              week_tc: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png"],
              week_sc: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 1,
              day_startY: 232,
              day_sc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              day_tc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              day_en_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 232,
              src: '014.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 70,
              month_startY: 232,
              month_sc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_tc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_en_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 119,
              y: 232,
              src: '014.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 140,
              year_startY: 232,
              year_sc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              year_tc_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              year_en_array: ["099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 290,
              hour_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 213,
              minute_startY: 290,
              minute_array: ["026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png","034.png","035.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 345,
              second_startY: 312,
              second_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 295,
              src: '036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  