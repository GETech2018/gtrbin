try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    * repack kostya_ung
    */
        'use strict';
	//dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$date$_$img_date = ''
        let normal$_$date$_$day$_$separator_img = ''
        let normal$_$week$_$week = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$digital_clock$_$img_time = ''
	let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        //dynamic modify end
        
        let rootPath = null
        let weekArray = null
	let week120Array = null
        //let weekArray_cn = null
	let batteryArray = null
	let stepArray = null
	let heartArray = null
        let timeArray = null
        let weekLevel = null

        let img_bg = null
        let timeText = null

        let whiteBigArr = null
        let whiteSmallArr = null
        let whiteSmall120Arr = null
        let grayBigArr = null
        let graySmallArr = null


        let cityText = null;
        let uviText = null;
        let aqiText = null
        let weekImages = new Array(4);
        let weatherIconImages = new Array(4);
        let weatherTextImages = new Array(4);
        let timeSensor = null;
        let weatherSensor = null;
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

            init_view() {
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                rootPath = "images/"

                weekArray = [
                    rootPath + "week/1.png",
                    rootPath + "week/2.png",
                    rootPath + "week/3.png",
                    rootPath + "week/4.png",
                    rootPath + "week/5.png",
                    rootPath + "week/6.png",
                    rootPath + "week/7.png",
                ]
		week120Array = [
                    rootPath + "week_120/1.png",
                    rootPath + "week_120/2.png",
                    rootPath + "week_120/3.png",
                    rootPath + "week_120/4.png",
                    rootPath + "week_120/5.png",
                    rootPath + "week_120/6.png",
                    rootPath + "week_120/7.png",
                ]
                batteryArray = [
                    rootPath + "battery/1.png",
                    rootPath + "battery/2.png",
                    rootPath + "battery/3.png",
                    rootPath + "battery/4.png",
                    rootPath + "battery/5.png",
                    rootPath + "battery/6.png",
                    rootPath + "battery/7.png",
                    rootPath + "battery/8.png",
                    rootPath + "battery/9.png",
                    rootPath + "battery/10.png",
                ]
		stepArray = [
                    rootPath + "step/1.png",
                    rootPath + "step/2.png",
                    rootPath + "step/3.png",
                    rootPath + "step/4.png",
                    rootPath + "step/5.png",
                    rootPath + "step/6.png",
                    rootPath + "step/7.png",
                    rootPath + "step/8.png",
                    rootPath + "step/9.png",
                    rootPath + "step/10.png",
                ]
		heartArray = [
                    rootPath + "heart/1.png",
                    rootPath + "heart/2.png",
                    rootPath + "heart/3.png",
                    rootPath + "heart/4.png",
                    rootPath + "heart/5.png",
                    rootPath + "heart/6.png",
                ]
                whiteBigArr = [
                    rootPath + "white_big_num/0.png",
                    rootPath + "white_big_num/1.png",
                    rootPath + "white_big_num/2.png",
                    rootPath + "white_big_num/3.png",
                    rootPath + "white_big_num/4.png",
                    rootPath + "white_big_num/5.png",
                    rootPath + "white_big_num/6.png",
                    rootPath + "white_big_num/7.png",
                    rootPath + "white_big_num/8.png",
                    rootPath + "white_big_num/9.png",
                ]
                whiteSmallArr = [
                    rootPath + "white_small_num/0.png",
                    rootPath + "white_small_num/1.png",
                    rootPath + "white_small_num/2.png",
                    rootPath + "white_small_num/3.png",
                    rootPath + "white_small_num/4.png",
                    rootPath + "white_small_num/5.png",
                    rootPath + "white_small_num/6.png",
                    rootPath + "white_small_num/7.png",
                    rootPath + "white_small_num/8.png",
                    rootPath + "white_small_num/9.png",

                ]
		whiteSmall120Arr = [
                    rootPath + "white_small_num_120/0.png",
                    rootPath + "white_small_num_120/1.png",
                    rootPath + "white_small_num_120/2.png",
                    rootPath + "white_small_num_120/3.png",
                    rootPath + "white_small_num_120/4.png",
                    rootPath + "white_small_num_120/5.png",
                    rootPath + "white_small_num_120/6.png",
                    rootPath + "white_small_num_120/7.png",
                    rootPath + "white_small_num_120/8.png",
                    rootPath + "white_small_num_120/9.png",

                ]
                grayBigArr = [
                    rootPath + "gray_big_num/0.png",
                    rootPath + "gray_big_num/1.png",
                    rootPath + "gray_big_num/2.png",
                    rootPath + "gray_big_num/3.png",
                    rootPath + "gray_big_num/4.png",
                    rootPath + "gray_big_num/5.png",
                    rootPath + "gray_big_num/6.png",
                    rootPath + "gray_big_num/7.png",
                    rootPath + "gray_big_num/8.png",
                    rootPath + "gray_big_num/9.png",

                ]
                timeArray = [
                    rootPath + "time/0.png",
                    rootPath + "time/1.png",
                    rootPath + "time/2.png",
                    rootPath + "time/3.png",
                    rootPath + "time/4.png",
                    rootPath + "time/5.png",
                    rootPath + "time/6.png",
                    rootPath + "time/7.png",
                    rootPath + "time/8.png",
                    rootPath + "time/9.png",
                ]
                weather_smallIcon_arr = [
                    rootPath + "weather/0.png",
                    rootPath + "weather/1.png",
                    rootPath + "weather/2.png",
                    rootPath + "weather/3.png",
                    rootPath + "weather/4.png",
                    rootPath + "weather/5.png",
                    rootPath + "weather/6.png",
                    rootPath + "weather/7.png",
                    rootPath + "weather/8.png",
                    rootPath + "weather/9.png",
                    rootPath + "weather/10.png",
                    rootPath + "weather/11.png",
                    rootPath + "weather/12.png",
                    rootPath + "weather/13.png",
                    rootPath + "weather/14.png",
                    rootPath + "weather/15.png",
                    rootPath + "weather/16.png",
                    rootPath + "weather/17.png",
                    rootPath + "weather/18.png",
                    rootPath + "weather/19.png",
                    rootPath + "weather/20.png",
                    rootPath + "weather/21.png",
                    rootPath + "weather/22.png",
                    rootPath + "weather/23.png",
                    rootPath + "weather/24.png",
                    rootPath + "weather/25.png",
                    rootPath + "weather/26.png",
                    rootPath + "weather/27.png",
                    rootPath + "weather/28.png",
                ];
                weather_bigIcon_arr = [
                    rootPath + "weatherBig/0.png",
                    rootPath + "weatherBig/1.png",
                    rootPath + "weatherBig/2.png",
                    rootPath + "weatherBig/3.png",
                    rootPath + "weatherBig/4.png",
                    rootPath + "weatherBig/5.png",
                    rootPath + "weatherBig/6.png",
                    rootPath + "weatherBig/7.png",
                    rootPath + "weatherBig/8.png",
                    rootPath + "weatherBig/9.png",
                    rootPath + "weatherBig/10.png",
                    rootPath + "weatherBig/11.png",
                    rootPath + "weatherBig/12.png",
                    rootPath + "weatherBig/13.png",
                    rootPath + "weatherBig/14.png",
                    rootPath + "weatherBig/15.png",
                    rootPath + "weatherBig/16.png",
                    rootPath + "weatherBig/17.png",
                    rootPath + "weatherBig/18.png",
                    rootPath + "weatherBig/19.png",
                    rootPath + "weatherBig/20.png",
                    rootPath + "weatherBig/21.png",
                    rootPath + "weatherBig/22.png",
                    rootPath + "weatherBig/23.png",
                    rootPath + "weatherBig/24.png",
                    rootPath + "weatherBig/25.png",
                    rootPath + "weatherBig/26.png",
                    rootPath + "weatherBig/27.png",
                    rootPath + "weatherBig/28.png",
                ];

            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: rootPath + 'img/background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 404,
              type: hmUI.data_type.HEART,
              font_array: whiteSmallArr,
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: rootPath + "img/white_small_invalid.png",
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 139,
              y: 297,
              image_array: heartArray,
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 404,
              type: hmUI.data_type.STEP,
              font_array: whiteSmallArr,
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 297,
              image_array: stepArray,
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 404,
              type: hmUI.data_type.BATTERY,
              font_array: whiteSmallArr,
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: rootPath + "img/procent.png",
              unit_tc: rootPath + "img/procent.png",
              unit_en: rootPath + "img/procent.png",
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 297,
              image_array: batteryArray,
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 94,
              month_startY: 139,
              month_sc_array: whiteSmall120Arr,
              month_tc_array: whiteSmall120Arr,
              month_en_array: whiteSmall120Arr,
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 3,
              month_is_character: false,
              day_startX: 16,
              day_startY: 139,
              day_sc_array: whiteSmall120Arr,
              day_tc_array: whiteSmall120Arr,
              day_en_array: whiteSmall120Arr,
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 3,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$date$_$day$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 140,
              w: 20,
              h: 32,
              src: rootPath + 'img/dayseparator_120.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 147,
              y: 140,
	      week_en:  week120Array,
              week_tc:  week120Array,
              week_sc:  week120Array,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 17,
              src: rootPath + 'img/bluetooth_red.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 129,
              y: 17,
              src: rootPath + 'img/lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 83,
              y: 17,
              src: rootPath + 'img/alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                let lan = hmSetting.getLanguage()
                var screenType = hmSetting.getScreenType();
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: -13,
                        y: -13,
                        w: 480,
                        h: 480,
                        color: 0x000000,
                    });
                } else {
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: -13,
                        y: -13,
                        w: 480,
                        h: 480,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                
                }
                timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 13,
                    hour_startY: 44,
                    hour_array: timeArray,
                    hour_space: 0,
                    hour_unit_sc: rootPath + "img/hourseparator.png", 
                    hour_unit_tc: rootPath + "img/hourseparator.png",
                    hour_unit_en: rootPath + "img/hourseparator.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, 
		    minute_startX: 148,
                    minute_startY: 44,
                    minute_array: timeArray,
                    minute_space: 0, 
                    minute_follow: 0, 
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ALL,

                });


                if (screenType == hmSetting.screen_type.WATCHFACE) {
                    cityText = hmUI.createWidget(hmUI.widget.TEXT, {
                        x: 285,
			y: 10,
                        w: 200,
                        h: 34,
                        //font_array: whiteSmallArr,
                        color: 0x979797,
                        align_h: hmUI.align.LEFT,
                        align_v: hmUI.align.CENTER_V,
                    });

                    //初始化天气widget
                    for (var i = 0; i < 4; i++) {
                        weekImages[i] = hmUI.createWidget(hmUI.widget.IMG, {
 			    x: 27 + i * 90,
 			   // x: 21 + i * 95,
			    y: 186,
                            w: 60,
                            h: 30 ,
                            show_level: hmUI.show_level.ONAL_NORMAL,
                        });

                        weatherIconImages[i] = hmUI.createWidget(hmUI.widget.IMG, {
			    x: 36 + i * 90,
			    //x: 30 + i * 95,
                            y: 223,
                            w: 48,
                            h: 48,
                            src: weather_smallIcon_arr[0],
                            show_level: hmUI.show_level.ONAL_NORMAL,
                        });
                        weatherTextImages[i] = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                            x: 33 + 90 * i,
                            //x: 27 + 95 * i,
                            y: 273,
                            w: 60,
                            h: 100,
                            font_array: whiteSmallArr,
                            h_space: 0,
                            align_h: hmUI.align.CENTER_H,
                            show_level: hmUI.show_level.ONAL_NORMAL,
                            unit_sc: rootPath + "img/white_small_du.png",
                            unit_en: rootPath + "img/white_small_du.png",
                            unit_tc: rootPath + "img/white_small_du.png",
                            negative_image: rootPath + "img/white_small_fu.png", 
                            invalid_image: rootPath + "img/white_small_invalid.png",
                        });


                    }
                
                       hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
			x: 280,
			//y: 40,
			y: 31,
                        image_array: weather_bigIcon_arr,
                        image_length: weather_bigIcon_arr.length,
                        type: hmUI.data_type.WEATHER,
                    });

                    //上边当前天气
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 282,
                        y: 107,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        //font_array: whiteBigArr,
			font_array: whiteSmall120Arr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        unit_sc: rootPath + "img/white_small_du_120.png",
                        unit_en: rootPath + "img/white_small_du_120.png",
                        unit_tc: rootPath + "img/white_small_du_120.png",
                        negative_image: rootPath + "img/white_small_fu_120.png", 
                        invalid_image: rootPath + "img/white_small_invalid_120.png",
                        padding: false, 
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    //上面低温
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 240,
                        y: 142,
                        type: hmUI.data_type.WEATHER_LOW,
                        font_array: grayBigArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        unit_sc: rootPath + "img/gray_big_du.png",
                        unit_en: rootPath + "img/gray_big_du.png",
                        unit_tc: rootPath + "img/gray_big_du.png",
                        negative_image: rootPath + "img/gray_big_fu.png", 
                        invalid_image: rootPath + "img/gray_big_invalid.png",
                        padding: false, 
                        show_level: hmUI.show_level.ONAL_NORMAL,
                    });
                    //上面高温
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 322,
                        y: 142,
                        type: hmUI.data_type.WEATHER_HIGH,
                        font_array: grayBigArr,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        unit_sc: rootPath + "img/gray_big_du.png",
                        unit_en: rootPath + "img/gray_big_du.png",
                        unit_tc: rootPath + "img/gray_big_du.png",
                        negative_image: rootPath + "img/gray_big_fu.png", 
                        invalid_image: rootPath + "img/gray_big_invalid.png",
                        padding: false, 
                        show_level: hmUI.show_level.ONAL_NORMAL,
                   });


                    setWeek();

                    //获取天气信息
                    const weatherData = weatherSensor.getForecastWeather();
                    cityText.setProperty(hmUI.prop.TEXT, weatherData.cityName);
                    const forecastData = weatherData.forecastData;
                    const weatherSize = forecastData.data.length;
                    let iconIndex = 0;
                    let weatherNum = "";
                    for (var index = 0; index < 4; index++) {
                        if ((index + 1) >= weatherSize) {
                            iconIndex = 25;
                            weatherNum = "";
                        } else {
                            const element = forecastData.data[index + 1];
                            iconIndex = element.index;
                            weatherNum = element.high + "";
                        }

                        weatherIconImages[index].setProperty(hmUI.prop.SRC, weather_smallIcon_arr[iconIndex]);
                        weatherTextImages[index].setProperty(hmUI.prop.TEXT, weatherNum);
                    }
                    // console.log("weather index++++++++++++++++++++++" + index);
                }

                function setImgPath(widget, path) {
                    widget.setProperty(hmUI.prop.SRC, path);
                }

                //// get week----------------------------------------10015
                function setWeek() {
                    let timer1 = timer.createTimer(0, 1000, (function (option) {
                        let week = timeSensor.week;
                        let lan = hmSetting.getLanguage()
                        if (week == 7) {
                            week = 1;
                        } else {
                            week += 1;
                        }
                        for (var i = 0; i < 4; i++) {
                            if (lan == 2) {
                                path = rootPath + "week/" + week + ".png";
                            } else {
                                path = rootPath + "week/" + week + ".png";
                            }
                            setImgPath(weekImages[i], path);
                            week++;
                            if (week == 8) {
                                week = 1;
                            }
                        }
                    }), {})
                }
 
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                        resume_call: (function () {
                            console.log('ui resume');
                            setWeek();
                            const weatherData = weatherSensor.getForecastWeather();
                            cityText.setProperty(hmUI.prop.TEXT, weatherData.cityName);
                            const forecastData = weatherData.forecastData;
                            const weatherSize = forecastData.data.length;
                            console.log("weatherCount++++++++++++++++++++++" + forecastData.count);
                            let iconIndex = 0;
                            let weatherNum = "";
                            for (var index = 0; index < 4; index++) {
                                if ((index + 1) >= weatherSize) {
                                    iconIndex = 25;
                                    weatherNum = "";
                                } else {
                                    const element = forecastData.data[index + 1];
                                    console.log("++++++++++++++++++++++weather info high=" + element.high + "low=" + element.low + "index=" + element.index);
                                    iconIndex = element.index;
                                    weatherNum = element.high + "";
                                }
                                weatherIconImages[index].setProperty(hmUI.prop.SRC, weather_smallIcon_arr[iconIndex]);
                                weatherTextImages[index].setProperty(hmUI.prop.TEXT, weatherNum);
                            }
                        }),
                        pause_call: (function () {
                            console.log('ui pause');
                        }),

                    });
                }
            },
            onInit() {
                console.log('index page.js on init invoke')
                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
