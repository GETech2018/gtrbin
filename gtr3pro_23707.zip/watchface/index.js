﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bck-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 345,
              font_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 346,
              src: 'cal-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 321,
              font_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              padding: false,
              h_space: 2,
              dot_image: 'dis-0001.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 322,
              src: 'dis-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 326,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 324,
              src: 'st-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 101,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 342,
              y: 61,
              src: 'cuo-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 100,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 58,
              src: 'bat-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 383,
              src: 'lu-0000.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 382,
              src: 'dn-0000.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 382,
              src: 'bl-0000.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 384,
              src: 'sv-0000.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 166,
              week_en: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              week_tc: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              week_sc: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 195,
              year_startY: 107,
              year_sc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_tc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_en_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 28,
              month_sc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_tc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_en_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 61,
              day_sc_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_tc_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_en_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 213,
              hour_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 213,
              minute_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 214,
              src: 'pun-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  