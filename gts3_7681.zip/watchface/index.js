    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''		
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$animation$_$first = ''
        let normal$_$animation$_$second = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let normal$_$battery$_$text$_$separator_img = ''
 		let idle$_$idle_background$_$bg = ''
		let idle$_$digital_clock$_$img_time = ''
		let idle$_$Text$_$text$_$text_img = ''
		let idle$_$analog_clock$_$time_pointer = ''

        const stepsArrayImg = new Array(5);
        const dateArrayImg = new Array(2);
		const batteryArrayImg = new Array(3);
		//let debugText = null;
        const ASCIIARRAY = ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"];

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

	normal$_$animation$_$first = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 206,
              y: 301,
              anim_path: '',
              anim_prefix: 'first_anim',
              anim_ext: 'png',
              anim_fps: 3,
              anim_size: 10,
              anim_repeat: true,
              repeat_count: 0,
              anim_status: hmUI.anim_status.START,
            });

                    
            normal$_$animation$_$second = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 144,
              y: 123,
              anim_path: '',
              anim_prefix: 'second_anim',
              anim_ext: 'png',
              anim_fps: 4,
              anim_size: 10,
              anim_repeat: true,
              repeat_count: 0,
              anim_status: hmUI.anim_status.START,
            });
           

	 normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 239,
              hour_posX: 30,
              hour_posY: 144,
              hour_path: 'hour.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 195,
              minute_centerY: 242,
              minute_posX: 23,
              minute_posY: 185,
              minute_path: 'minute.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 425,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '83.png',
              unit_en: '83.png',
              negative_image: '82.png',
              invalid_image: '84.png',
              padding: false,
              isCharacter: false
            });
		
 	normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 18,
              y: 1,
              week_en: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_tc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_sc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 243,
              month_startY: 18,
              month_sc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_tc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_en_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
			show_level: hmUI.show_level.ONLY_NORMAL,
            });			

      /*     normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 407,
              image_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	*/

		stepsArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 155,
				pos_y: 427,
				center_x: 195,
				center_y: 240,
				angle: 39,
				src: '02.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 155,
				pos_y: 427,
				center_x: 195,
				center_y: 240,
				angle: 33,
				src: '03.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 155,
				pos_y: 427,
				center_x: 195,
				center_y: 240,
				angle: 27,
				src: '04.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[3] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 155,
				pos_y: 427,
				center_x: 195,
				center_y: 240,
				angle: 21,
				src: '05.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[4] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 155,
				pos_y: 427,
				center_x: 195,
				center_y: 240,
				angle: 15,
				src: '06.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 395,
				y: 0,
				w: 80,
				h: 24,
				text_size: 24,
				char_space: 1,
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});

			var step = hmSensor.createSensor(hmSensor.id.STEP);	
			var stepCurrent=step.current;			
			debugText.setProperty(hmUI.prop.TEXT, String(step.current));
			let stepString = String(step.current);			
            let index = 0;
			for (var i = 1; i < 5; i++) {
				stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
			}				
			for (let char of stepString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 5) {
					break;
				}
				stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}


			batteryArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 180,
				pos_y: 425,
				//center_x: 240,
				//center_y: 240,
				center_x: 195,
				center_y: 225,
				angle: -39,
				src: '02.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			batteryArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 180,
				pos_y: 425,
				center_x: 195,
				center_y: 225,
				angle: -43,
				src: '03.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			batteryArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 180,
				pos_y: 425,
				center_x: 195,
				center_y: 225,
				angle: -47,
				src: '04.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});			

			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 395,
				y: 20,
				w: 50,
				h: 24,
				text_size: 24,
				char_space: 1,
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});

			var battery = hmSensor.createSensor(hmSensor.id.BATTERY);			
			var batteryCurrent=battery.current;			
			debugText.setProperty(hmUI.prop.TEXT, String(battery.current));
			let batteryString = String(battery.current);			
           index = 0;
			for (var i = 1; i < 3; i++) {
				batteryArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
			}				
			for (let char of batteryString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 3) {
					break;
				}
				batteryArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}

			dateArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 192,
				pos_y: -6,
				center_x: 195,
				center_y: 170,
				angle: 374,
				src: '02.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			dateArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 390,
				h: 450,
				pos_x: 192,
				pos_y: -6,
				center_x: 195,
				center_y: 170,
				angle: 382,
				src: '03.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			var date = hmSensor.createSensor(hmSensor.id.TIME);
			let dateDay = date.day;
			let dateString = String(date.day);
			
			index = 0;
			dateArrayImg[0].setProperty(hmUI.prop.SRC, '06.png');
			if (dateDay < 10) {
				index = 1;
			}
				for (let char of dateString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 2) {
					break;
				}
				dateArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}		

					const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
						console.log('ui resume');
						console.log('ui resume');
						console.log('ui resume');

				   var stepCurrent=step.current;
					debugText.setProperty(hmUI.prop.TEXT, String(stepCurrent));
					index = 0;
					for (var i = 1; i < 5; i++) {
						stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					}
					for (let char of String(stepCurrent)) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 5) {
							break;
						}
						stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
				}
				
				
					var batteryCurrent=battery.current; 
					debugText.setProperty(hmUI.prop.TEXT, String(batteryCurrent));
					index = 0;
					for (var i = 1; i < 3; i++) {
						batteryArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					}
					for (let char of String(batteryCurrent)) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 3) {
							break;
						}
						batteryArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
	 
					dateDay = date.day;
					dateString = String(date.day);
					debugText.setProperty(hmUI.prop.TEXT, String(dateString));
					index = 0;
					dateArrayImg[0].setProperty(hmUI.prop.SRC, '02.png');
					if (dateDay < 10) {
						index = 1;
					}
						
					for (let char of dateString) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 2) {
							break;
						}
						
						debugText.setProperty(hmUI.prop.TEXT, String(index));
						dateArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
 

							}),
						});

	normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 407,
              image_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

	   normal$_$battery$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 342,
              y: 350,
              w: 30,
              h: 35,
              src: 'procent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 195,
              hour_centerY: 239,
              hour_posX: 30,
              hour_posY: 144,
              hour_path: 'hour.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 195,
              minute_centerY: 242,
              minute_posX: 23,
              minute_posY: 185,
              minute_path: 'minute.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  

            //dynamic modify end
          },
        
			
		

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
