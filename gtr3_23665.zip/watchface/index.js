﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Reba_I.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -255,
              y: 0,
              font_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              padding: false,
              h_space: -444,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -256,
              y: -29,
              font_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              padding: true,
              h_space: -444,
              unit_sc: '21.png',
              unit_tc: '21.png',
              unit_en: '21.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Aguja.png',
              center_x: 226,
              center_y: 122,
              x: 226,
              y: 121,
              start_angle: -301,
              end_angle: 0,
              cover_path: 'Back_agu.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 73,
              year_startY: 0,
              year_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              year_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              year_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              year_zero: 0,
              year_space: -444,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 45,
              month_startY: 0,
              month_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              month_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              month_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              month_zero: 1,
              month_space: -444,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 20,
              day_startY: 0,
              day_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_zero: 1,
              day_space: -444,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_tc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_sc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '12.png',
              hour_centerX: 226,
              hour_centerY: 122,
              hour_posX: 225,
              hour_posY: 121,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Mins.png',
              minute_centerX: 226,
              minute_centerY: 332,
              minute_posX: 226,
              minute_posY: 331,
              minute_cover_path: 'Ontop.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Aguja.png',
              second_centerX: 226,
              second_centerY: 332,
              second_posX: 226,
              second_posY: 121,
              second_cover_path: 'Segs_back.png',
              second_cover_x: -1,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 282,
              w: 100,
              h: 100,
              src: '001.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 226,
              w: 100,
              h: 55,
              src: '001.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 181,
              w: 121,
              h: 47,
              src: '001.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Aod1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '12.png',
              hour_centerX: 226,
              hour_centerY: 122,
              hour_posX: 225,
              hour_posY: 121,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Mins.png',
              minute_centerX: 226,
              minute_centerY: 332,
              minute_posX: 226,
              minute_posY: 331,
              minute_cover_path: 'Ontop.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  