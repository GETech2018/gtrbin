
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$jumpable$_$img_click = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart$_$jumpable$_$img_click = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$jumpable$_$img_click = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$step$_$current$_$text_img = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$image_progress$_$img_level = ''
        let idle$_$pai$_$weekly$_$text_img = ''
        let idle$_$battery$_$text$_$text_img = ''
        let idle$_$battery$_$image_progress$_$img_level = ''
        let idle$_$calorie$_$current$_$text_img = ''
        let idle$_$distance$_$text$_$text_img = ''
        let idle$_$weather$_$image_progress$_$img_level = ''
        let idle$_$temperature$_$current$_$text_img = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 77,
              hour_startY: 185,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 11,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 266,
              minute_startY: 185,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 11,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 409,
              am_y: 179,
              am_en_path: '12.png',
              pm_x: 409,
              pm_y: 179,
              pm_en_path: '13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 420,
              y: 226,
              src: '14.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 256,
              src: '15.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 420,
              y: 200,
              src: '16.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 105,
              month_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 207,
              day_startY: 44,
              day_sc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_tc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_en_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 0,
              day_follow: 0,
              day_space: 6,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 190,
              y: 164,
              week_en: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              week_tc: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              week_sc: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 307,
              type: hmUI.data_type.STEP,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 307,
              w: 30,
              h: 30,
              src: '56.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 304,
              type: hmUI.data_type.HEART,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '57.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });

            normal$_$heart$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 340,
              w: 30,
              h: 30,
              src: '56.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 89,
              y: 342,
              image_array: ["58.png","59.png","60.png","61.png","62.png","63.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 304,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 436,
              type: hmUI.data_type.BATTERY,
              font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '74.png',//单位
              unit_tc: '74.png',//单位
              unit_en: '74.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 192,
              y: 437,
              image_array: ["75.png","76.png","77.png","78.png","79.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 364,
              type: hmUI.data_type.CAL,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 365,
              type: hmUI.data_type.DISTANCE,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '90.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 128,
              y: 48,
              image_array: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 58,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '122.png',//单位
              unit_en: '123.png',//单位
              negative_image: '121.png', //负号图片
              invalid_image: '120.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 48,
              w: 30,
              h: 30,
              src: '124.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_path: '125.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '126.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 77,
              hour_startY: 185,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 11,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 266,
              minute_startY: 185,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 11,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 409,
              am_y: 179,
              am_en_path: '12.png',
              pm_x: 409,
              pm_y: 179,
              pm_en_path: '13.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 105,
              month_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 207,
              day_startY: 44,
              day_sc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_tc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_en_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 0,
              day_follow: 0,
              day_space: 6,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 190,
              y: 164,
              week_en: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              week_tc: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              week_sc: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 307,
              type: hmUI.data_type.STEP,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 304,
              type: hmUI.data_type.HEART,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '57.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 89,
              y: 342,
              image_array: ["58.png","59.png","60.png","61.png","62.png","63.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 304,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 436,
              type: hmUI.data_type.BATTERY,
              font_array: ["64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '74.png',//单位
              unit_tc: '74.png',//单位
              unit_en: '74.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 192,
              y: 437,
              image_array: ["75.png","76.png","77.png","78.png","79.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 364,
              type: hmUI.data_type.CAL,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 365,
              type: hmUI.data_type.DISTANCE,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '90.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 128,
              y: 48,
              image_array: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 58,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '122.png',//单位
              unit_en: '123.png',//单位
              negative_image: '121.png', //负号图片
              invalid_image: '120.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  