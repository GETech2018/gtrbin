
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$sun$_$high$_$text_img = ''
        let normal$_$sun$_$low$_$text_img = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$analog_clock$_$time_pointer = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$battery$_$text$_$text_img = ''
        let idle$_$battery$_$image_progress$_$img_level = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$step$_$current$_$text_img = ''
        let idle$_$step$_$image_progress$_$img_level = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$image_progress$_$img_level = ''
        let idle$_$distance$_$text$_$text_img = ''
        let idle$_$calorie$_$current$_$text_img = ''
        let idle$_$pai$_$weekly$_$text_img = ''
        let idle$_$temperature$_$current$_$text_img = ''
        let idle$_$weather$_$image_progress$_$img_level = ''
        let idle$_$sun$_$high$_$text_img = ''
        let idle$_$sun$_$low$_$text_img = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 49,
              second_posY: 240,
              second_path: '2.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 162,
              hour_startY: 98,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_space: 6,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 294,
              minute_startY: 98,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_space: 6,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 404,
              second_startY: 137,
              second_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              second_space: 4,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 158,
              am_y: 182,
              am_en_path: '23.png',
              pm_x: 206,
              pm_y: 182,
              pm_en_path: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 228,
              src: '25.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 183,
              src: '26.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 287,
              src: '27.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 189,
              type: hmUI.data_type.BATTERY,
              font_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 204,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 54,
              month_startY: 200,
              month_sc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_tc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_en_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 158,
              day_startY: 310,
              day_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 6,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 55,
              y: 200,
              week_en: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              week_tc: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              week_sc: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 225,
              type: hmUI.data_type.STEP,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 322,
              y: 182,
              image_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 422,
              type: hmUI.data_type.HEART,
              font_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '97.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 434,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 275,
              type: hmUI.data_type.DISTANCE,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '104.png', //小数点图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 325,
              type: hmUI.data_type.CAL,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.LEFT,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 374,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 135,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '107.png',//单位
              unit_en: '108.png',//单位
              negative_image: '106.png', //负号图片
              invalid_image: '105.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 58,
              image_array: ["109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 46,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '149.png', //小数点图片
              invalid_image: '148.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 46,
              type: hmUI.data_type.SUN_SET,
              font_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '151.png', //小数点图片
              invalid_image: '150.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '152.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 162,
              hour_startY: 98,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_space: 6,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 294,
              minute_startY: 98,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_space: 6,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 158,
              am_y: 182,
              am_en_path: '23.png',
              pm_x: 206,
              pm_y: 182,
              pm_en_path: '24.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 6,
              y: 189,
              type: hmUI.data_type.BATTERY,
              font_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 204,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 54,
              month_startY: 200,
              month_sc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_tc_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_en_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 158,
              day_startY: 310,
              day_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 6,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 55,
              y: 200,
              week_en: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              week_tc: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              week_sc: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 225,
              type: hmUI.data_type.STEP,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 322,
              y: 182,
              image_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 422,
              type: hmUI.data_type.HEART,
              font_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '153.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 434,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 275,
              type: hmUI.data_type.DISTANCE,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '104.png', //小数点图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 325,
              type: hmUI.data_type.CAL,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.LEFT,
              h_space: 3,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 374,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 135,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '107.png',//单位
              unit_en: '108.png',//单位
              negative_image: '106.png', //负号图片
              invalid_image: '105.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 58,
              image_array: ["109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 46,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '149.png', //小数点图片
              invalid_image: '148.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 46,
              type: hmUI.data_type.SUN_SET,
              font_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '151.png', //小数点图片
              invalid_image: '150.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  