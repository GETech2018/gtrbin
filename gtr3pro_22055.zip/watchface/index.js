﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 155,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -67,
              day_startY: 148,
              day_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              day_zero: 1,
              day_space: -8,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 23,
              month_startY: 25,
              month_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -179,
              hour_startY: 76,
              hour_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              hour_zero: 1,
              hour_space: -89,
              hour_align: hmUI.align.LEFT,

              minute_startX: -101,
              minute_startY: 66,
              minute_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              minute_zero: 1,
              minute_space: -89,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 2,
              second_startY: 62,
              second_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              second_zero: 1,
              second_space: -8,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 85,
              am_y: 119,
              am_sc_path: '41.png',
              am_en_path: '41.png',
              pm_x: 85,
              pm_y: 119,
              pm_sc_path: '42.png',
              pm_en_path: '42.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 272,
              y: 235,
              src: '43.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 271,
              y: 265,
              src: '44.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 267,
              src: '45.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 401,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 281,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '56.png',
              center_x: 132,
              center_y: 289,
              x: 8,
              y: 62,
              start_angle: 1,
              end_angle: 355,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 336,
              w: 32,
              h: 32,
              src: '57.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 165,
              w: 32,
              h: 32,
              src: '135.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '58.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 23,
              hour_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '60.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 209,
              minute_cover_path: '59.png',
              minute_cover_x: 221,
              minute_cover_y: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '61.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 23,
              second_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 290,
              font_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 160,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              padding: false,
              h_space: 0,
              invalid_image: '72.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '73.png',
              center_x: 344,
              center_y: 169,
              x: 8,
              y: 58,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 318,
              y: 275,
              image_array: ["74.png","75.png","76.png","77.png","78.png","79.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 376,
              font_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 326,
              font_array: ["80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              padding: false,
              h_space: 0,
              unit_sc: '91.png',
              unit_tc: '91.png',
              unit_en: '91.png',
              dot_image: '90.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 172,
              image_array: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 204,
              font_array: ["121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png"],
              padding: false,
              h_space: 0,
              unit_sc: '134.png',
              unit_tc: '134.png',
              unit_en: '134.png',
              negative_image: '132.png',
              invalid_image: '131.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  