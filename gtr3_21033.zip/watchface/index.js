
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

		var screenType = hmSetting.getScreenType();
		
        //dynamic modify start
        let normal$_$background$_$bg = ''
		let normal$_$Moonphase$_$img = ''
		let normal$_$Mooncover$_$img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$battery$_$pointer_progress$_$img_pointer = ''
        let normal$_$week$_$week = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
		let normal$_$system$_$lock$_$img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$sunrise$_$current$_$text_img = ''
        let normal$_$sunrise$_$current$_$img = ''
        let normal$_$sunset$_$current$_$text_img = ''
        let normal$_$temperature$_$current$_$text_img = ''
       // let normal$_$calorie$_$current$_$text_img = ''
	    let normal$_$analog_clock_Seconds$_$time_pointer = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$analog_clock$_$time_pointer = ''
		let animCreate = null
		let moon_timer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
            
			
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
               	//Moon phase here
				normal$_$Moonphase$_$img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,//display screen width
                    h: 454,//display screen height
                    pos_x: 231,
                    pos_y: 43,
					center_x: 301,
                    center_y: 112,
                    angle: 90,
					src: '111.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				normal$_$Mooncover$_$img = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 43,
					src: '110.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});


const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
    	resume_call: (function () {
		var timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        var currentDay = timeSensor.day;
        var currentMonth = timeSensor.month;
		var currentYear = timeSensor.year;
		var c = e = jd = b = 0;
		if (currentMonth < 3) {
			currentYear--;
			currentMonth += 12;
		}
		++currentMonth;
		c = 365.25 * currentYear;
		e = 30.601 * currentMonth;
		jd = c + e + currentDay - 694039.09; //jd is total days elapsed
		jd /= 29.5305882; //divide by the moon cycle
		b = parseInt(jd); //int(jd) -> b, take integer part of jd
		jd -= b; //subtract integer part to leave fractional part of original jd
		var angle = Math.round(jd * 179); //scale fraction from 0-360 and round
		normal$_$Moonphase$_$img.setProperty(hmUI.prop.ANGLE, angle);
		}),
	});

if (screenType != hmSetting.screen_type.AOD) {
	// animate
    animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 18,
                        y: 133,
                        anim_path: "anim",
                        anim_prefix: "ani",
                        anim_ext: "png",
                        anim_fps: 2,
                        anim_size: 10,
                        anim_repeat: false,
                        repeat_count: 0,
                        anim_status: 1,
                        anim_complete_call:this._animNext,
                    });
}
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 67,
              month_startY: 260,
              month_sc_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png"],
              month_tc_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png"],
              month_en_array: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 345,
              day_startY: 209,
              day_sc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_tc_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_en_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
            normal$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '109.png',
              center_x: 328,
              center_y: 329,
              x: 18,
              y: 66,
              type: hmUI.data_type.BATTERY,
              start_angle: 225,
              end_angle: 400,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 292,
              y: 209,
              week_en: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              week_tc: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              week_sc: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 109,
              src: '72.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 109,
              src: '108.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 324,
              src: '73.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 324,
              src: '112.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 344,
              type: hmUI.data_type.HEART,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '70.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 289,
              y: 344,
              image_array: ["81.png","82.png","83.png","84.png","85.png"],
              image_length: 5,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 277,
              type: hmUI.data_type.STEP,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 292,
              image_array: ["76.png","77.png","78.png","79.png","80.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 298,
              type: hmUI.data_type.DISTANCE,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  unit_sc: '22.png',//单位
              unit_tc: '22.png',//单位
              unit_en: '87.png',
              dot_image: '23.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 107,
              image_array: ["41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 127,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '71.png',//单位
              unit_en: '71.png',//单位
              invalid_image: '70.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });

                    
            normal$_$sunrise$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 75,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '70.png',// 无数据时显示的图片
			  dot_image: '23a.png',
              padding: false,
              isCharacter: false
            });  

                    
            normal$_$sunset$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 109,
              type: hmUI.data_type.SUN_SET,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '70.png',// 无数据时显示的图片
			  dot_image: '23a.png',
              padding: false,
              isCharacter: false
            });                      
           // normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
           //   x: 82,
           //   y: 102,
           //   type: hmUI.data_type.CAL,
           //   font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
           //   align_h: hmUI.align.CENTER_H,
           //   h_space: 0,
           //   show_level: hmUI.show_level.ONLY_NORMAL,
           //   padding: false,
           //   isCharacter: false
           // });
            normal$_$analog_clock_Seconds$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
               second_centerX: 110,
              second_centerY: 227,
              second_posX: 7,
              second_posY: 95,
              second_path: '2.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
			  hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 212,
              hour_path: '74.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 212,
              minute_path: '75.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 212,
              hour_path: '107.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 212,
              minute_path: '106.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  