﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let	normal$_$weather$_$image_progress$_$img_level = ''
		let normal$_$temperature$_$current$_$text_img = ''	
		let normal$_$heart_rate$_$text$_$text_img = ''
		let	normal$_$digital_clock$_$img_time = ''
		let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
		let normal$_$battery$_$text$_$text_img = ''
		let normal$_$Text$_$text$_$text_img = ''
		let idle$_$idle_background$_$bg = ''
		let idle$_$digital_clock$_$img_time = ''
		let idle$_$Text$_$text$_$text_img = ''
        const stepsArrayImg = new Array(5);
        const dateArrayImg = new Array(2);
		let debugText = null;
        const ASCIIARRAY = ["number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png","number_10.png","number_11.png","number_12.png"];


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 10,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png","number_10.png","number_11.png","number_12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '83.png',
              unit_en: '83.png',
              negative_image: '82.png',
              invalid_image: '84.png',
              padding: false,
              isCharacter: false
            });

           normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 147,
              y: 19,
              image_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

			  normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 143,
              hour_startY: 171,
              hour_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 318,
              minute_startY: 157,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });                    

			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {

			  x: 57,
			  y: 171,
			  w: 454,
                                          h: 454,
			  src: 'setka.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 
			
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 375,
              month_startY: 248,
              month_sc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_tc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_en_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
			show_level: hmUI.show_level.ONLY_NORMAL,
            });			
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 16,
              y: 254,
              week_en: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_tc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_sc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 105,
              type: hmUI.data_type.HEART,
              font_array: ["number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png","number_10.png","number_11.png","number_12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '84.png',
              padding: false,
              isCharacter: false
            });

            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 413,
              type: hmUI.data_type.BATTERY,
              font_array: ["number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png","number_10.png","number_11.png","number_12.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '81.png',
              unit_en: '81.png',			  
              padding: false,
              isCharacter: false
            });

			stepsArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 10,
				center_x: 228,
				center_y: 228,
				angle: 300,
				src: 'number_3.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 10,
				center_x: 228,
				center_y: 228,
				angle: 306,
				src: 'number_4.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 10,
				center_x: 228,
				center_y: 228,
				angle: 312,
				src: 'number_5.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[3] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 10,
				center_x: 228,
				center_y: 228,
				angle: 318,
				src: 'number_6.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[4] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 10,
				center_x: 228,
				center_y: 228,
				angle: 324,
				src: 'number_7.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 0,
				w: 95,
				h: 23,
				text_size: 24,
				char_space: 2, //межсимвольный интервал
				//text_style: hmUI.text_style.CHAR_WRAP,
				//text: "Test",
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});

			var step = hmSensor.createSensor(hmSensor.id.STEP);			
			var stepCurrent=step.current;			
			debugText.setProperty(hmUI.prop.TEXT, String(step.current));
			let stepString = String(step.current);			
            let index = 0;
			for (var i = 1; i < 5; i++) {
				stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
			}				
			for (let char of stepString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 5) {
					break;
				}
				stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}
           
			dateArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 219,
				pos_y: 418,
				center_x: 228,
				center_y: 228,
				angle: -39,
				src: 'number_3.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			dateArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 219,
				pos_y: 418,
				center_x: 228,
				center_y: 228,
				angle: -45,
				src: 'number_4.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			var date = hmSensor.createSensor(hmSensor.id.TIME);
			let dateDay = date.day;
			let dateString = String(date.day);
			
			index = 0;
			//for (var i = 1; i < 5; i++) {
			//	dateArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
			//}
			dateArrayImg[0].setProperty(hmUI.prop.SRC, 'number_7.png');
			if (dateDay < 10) {
				index = 1;
			}
				for (let char of dateString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 2) {
					break;
				}
				dateArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                   console.log('ui resume');
                   
				   console.log('ui resume');
				   var stepCurrent=step.current;
				   
					//stepString=String(stepCurrent);
					
					debugText.setProperty(hmUI.prop.TEXT, String(stepCurrent));
					index = 0;
					for (var i = 1; i < 5; i++) {
						stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					}
					for (let char of String(stepCurrent)) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 5) {
							break;
						}
						stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
					
					dateDay = date.day;
					dateString = String(date.day);
					debugText.setProperty(hmUI.prop.TEXT, String(dateString));
					
					index = 0;
					//for (var i = 1; i < 5; i++) {
					//	dateArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					//}
					dateArrayImg[0].setProperty(hmUI.prop.SRC, 'number_3.png');
					if (dateDay < 10) {
						index = 1;
					}
						
					for (let char of dateString) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 2) {
							break;
						}
						
					debugText.setProperty(hmUI.prop.TEXT, String(index));
						dateArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
					
                }),
            });


			idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: 0x000000,
              show_level: hmUI.show_level.ONAL_AOD,
            });
		
		
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
			 
              hour_zero: 1,
              hour_startX: 143,
              hour_startY: 171,
              hour_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 318,
              minute_startY: 157,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              show_level: hmUI.show_level.ONAL_AOD,
			  });

			idle$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 57,
			  y: 171,
			  w: 454,
                                          h: 454,
			  src: 'setka.png',			
			show_level: hmUI.show_level.ONAL_AOD,			
				}); 		
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  

