﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 507,
              h: 507,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 285,
              y: 16,
              src: 'System_Bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 22,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 74,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Font_13.png',
              unit_tc: 'Weather_Font_13.png',
              unit_en: 'Weather_Font_13.png',
              negative_image: 'Weather_Font_12.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 79,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 31,
              image_array: ["moon1.png","moon2.png","moon3.png","moon4.png","moon5.png","moon6.png","moon7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 436,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 163,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 195,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 228,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 284,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_hand.png',
              center_x: 108,
              center_y: 275,
              x: 13,
              y: 70,
              start_angle: 90,
              end_angle: 271,
              cover_path: 'Batt_line.png',
              cover_x: 31,
              cover_y: 264,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 361,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'act_font_11.png',
              unit_tc: 'act_font_11.png',
              unit_en: 'act_font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 339,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 389,
              image_array: ["Step_line_01.png","Step_line_02.png","Step_line_03.png","Step_line_04.png","Step_line_05.png","Step_line_06.png","Step_line_07.png","Step_line_08.png","Step_line_09.png","Step_line_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 91,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 55,
              y: 129,
              week_en: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_tc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_sc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 61,
              month_startY: 92,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 297,
              am_y: 164,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 297,
              pm_y: 164,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 177,
              hour_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 163,
              minute_startY: 177,
              minute_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds_hand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 49,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 172,
              w: 45,
              h: 81,
              src: 'A-empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 5,
              w: 47,
              h: 42,
              src: 'A-empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 22,
              w: 55,
              h: 42,
              src: 'A-empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 64,
              w: 90,
              h: 49,
              src: 'A-empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 117,
              w: 82,
              h: 39,
              src: 'A-empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 348,
              y: 161,
              w: 114,
              h: 45,
              src: 'A-empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 321,
              w: 53,
              h: 53,
              src: 'A-empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 507,
              h: 507,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 285,
              y: 16,
              src: 'System_Bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 22,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 74,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Font_13.png',
              unit_tc: 'Weather_Font_13.png',
              unit_en: 'Weather_Font_13.png',
              negative_image: 'Weather_Font_12.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 79,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 31,
              image_array: ["moon1.png","moon2.png","moon3.png","moon4.png","moon5.png","moon6.png","moon7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 436,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 163,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 195,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 228,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 284,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_hand.png',
              center_x: 108,
              center_y: 275,
              x: 13,
              y: 70,
              start_angle: 90,
              end_angle: 271,
              cover_path: 'Batt_line.png',
              cover_x: 31,
              cover_y: 264,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 361,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'act_font_11.png',
              unit_tc: 'act_font_11.png',
              unit_en: 'act_font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 339,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 389,
              image_array: ["Step_line_01.png","Step_line_02.png","Step_line_03.png","Step_line_04.png","Step_line_05.png","Step_line_06.png","Step_line_07.png","Step_line_08.png","Step_line_09.png","Step_line_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 91,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 55,
              y: 129,
              week_en: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_tc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_sc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 61,
              month_startY: 92,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 297,
              am_y: 164,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 297,
              pm_y: 164,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 177,
              hour_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 163,
              minute_startY: 177,
              minute_array: ["Time_HM_font_01.png","Time_HM_font_02.png","Time_HM_font_03.png","Time_HM_font_04.png","Time_HM_font_05.png","Time_HM_font_06.png","Time_HM_font_07.png","Time_HM_font_08.png","Time_HM_font_09.png","Time_HM_font_10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds_hand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 49,
              second_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  