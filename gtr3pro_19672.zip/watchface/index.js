try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * hugray_small_numiOS bundle tool v1.0.17
    * Copyright © Hugray_small_numi. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
 
    let timeArray = null
    let dataArray =null 
    let dateRedArr = null
    let dateWhiteArr = null
    let bg = null
    let aodBg = null
    let snowAnimate = null
    let weekArr = null
    let bgPath = "img/bg1.png"
    let weekRedArr = null
    let heartTxt = null


    let countDownTimer = null
    let dateImg = null
    let  countArray = null
    let timeSensor = hmSensor.createSensor(hmSensor.id.TIME)
    let day1 = null
    let day2 = null
    let timeText = null
    let weekImg = null
    let heartIcon = null
    let heartIcon3 = null
    let heartTxt3 = null 

    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

     

        init_view() {
           
            rootPath = "images/",
            timeArray = [
                rootPath +  "time/time_0.png",
                rootPath +  "time/time_1.png",
                rootPath +  "time/time_2.png",
                rootPath +  "time/time_3.png",
                rootPath +  "time/time_4.png",
                rootPath +  "time/time_5.png",
                rootPath +  "time/time_6.png",
                rootPath +  "time/time_7.png",
                rootPath +  "time/time_8.png",
                rootPath +  "time/time_9.png",
            ]
            
            dateRedArr = [
                rootPath + "date/red_0.png",
                rootPath + "date/red_1.png",
                rootPath + "date/red_2.png",
                rootPath + "date/red_3.png",
                rootPath + "date/red_4.png",
                rootPath + "date/red_5.png",
                rootPath + "date/red_6.png",
                rootPath + "date/red_7.png",
                rootPath + "date/red_8.png",
                rootPath + "date/red_9.png",
            ]
            dateWhiteArr = [
                rootPath + "date_white/white_0.png",
                rootPath + "date_white/white_1.png",
                rootPath + "date_white/white_2.png",
                rootPath + "date_white/white_3.png",
                rootPath + "date_white/white_4.png",
                rootPath + "date_white/white_5.png",
                rootPath + "date_white/white_6.png",
                rootPath + "date_white/white_7.png",
                rootPath + "date_white/white_8.png",
                rootPath + "date_white/white_9.png",
            ]
            weekArr = [
                rootPath + "week/week_1.png",
                rootPath + "week/week_2.png",
                rootPath + "week/week_3.png",
                rootPath + "week/week_4.png",
                rootPath + "week/week_5.png",
                rootPath + "week/week_6.png",
                rootPath + "week/week_7.png",
            ]
            weekRedArr = [
                rootPath + "week_red/week_1.png",
                rootPath + "week_red/week_2.png",
                rootPath + "week_red/week_3.png",
                rootPath + "week_red/week_4.png",
                rootPath + "week_red/week_5.png",
                rootPath + "week_red/week_6.png",
                rootPath + "week_red/week_7.png",
            ]
            countArray= [
                rootPath + "countDown/0.png",
                rootPath + "countDown/1.png",
                rootPath + "countDown/2.png",
                rootPath + "countDown/3.png",
                rootPath + "countDown/4.png",
                rootPath + "countDown/5.png",
                rootPath + "countDown/6.png",
                rootPath + "countDown/7.png",
                rootPath + "countDown/8.png",
                rootPath + "countDown/9.png",
            ]
            timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        
            aodBg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                color: 0x000000,
                show_level: hmUI.show_level.ONLY_AOD,  
            });
            bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src:  rootPath + bgPath,
              show_level: hmUI.show_level.ONLY_NORMAL,   
            });
              // /* 
           snowAnimate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 0,
            y: 0,
            //w: 960,
            //h: 960,
           // align_h: hmUI.align.CENTER_H,
            //align_v: hmUI.align.CENTER_V,
            anim_path: rootPath + "snow",
            anim_prefix: "snow",
            anim_ext: "png",
            anim_fps: 30,
            anim_size: 75,
           // step:2,
            anim_repeat: true,
            repeat_count: 0,
            anim_status: 1,
            display_on_restart:true,
            show_level: hmUI.show_level.ONLY_NORMAL,
        });//*/
            weekImg = hmUI.createWidget(hmUI.widget.IMG_WEEK);
            dateImg = hmUI.createWidget(hmUI.widget.IMG_DATE);
            timeText = hmUI.createWidget(hmUI.widget.IMG_TIME);
            heartTxt =  hmUI.createWidget(hmUI.widget.TEXT_IMG);
            heartIcon = hmUI.createWidget(hmUI.widget.IMG);
            heartTxt3 =  hmUI.createWidget(hmUI.widget.TEXT_IMG);
            heartIcon3= hmUI.createWidget(hmUI.widget.IMG);
            day1 = hmUI.createWidget(hmUI.widget.IMG);
            day2 = hmUI.createWidget(hmUI.widget.IMG);
            var screenType = hmSetting.getScreenType();
            if(screenType == hmSetting.screen_type.AOD){
                if(bgPath == "img/bg3.png")
                {
                   // heartTxt.setProperty(hmUI.prop.VISIBLE, false);
                   // heartIcon.setProperty(hmUI.prop.VISIBLE,false);
                }
               // console.log("==============aod: bgpath:"+bgPath)
            }else{
                day1. setProperty(hmUI.prop.MORE,{
                    x: 242,
                    y: 357,
                    w: 35,
                    h: 46,
                    src:  countArray[0],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                day2.setProperty(hmUI.prop.MORE,{
                    x: 278,
                    y: 357,
                    w: 35,
                    h: 46,
                    src:  countArray[0],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
            } 
            showTime(); 
            showHeart();
            function showTime(){
                timeText.setProperty(hmUI.prop.MORE, {
                    hour_startX: 110,
                    hour_startY: 77,
                    hour_array: timeArray,
                    hour_space: 2,
                    hour_zero: 1,
                    hour_unit_sc: rootPath+"img/colon.png", //单位
                    hour_unit_tc: rootPath+"img/colon.png",
                    hour_unit_en: rootPath+"img/colon.png",
                    hour_align: hmUI.align.LEFT,

                    minute_zero: 1, //是否补零 1为补零
                    minute_startX: 253,
                    minute_startY: 77,
                    minute_array: timeArray,
                    minute_space: 2, //两个图片间隔 对应GT2的interval
                    minute_follow: 0, //是否跟随
                    minute_align: hmUI.align.LEFT,
                    show_level: hmUI.show_level.ALL,
                   
                    });
    
                    weekImg.setProperty(hmUI.prop.MORE,{
                        x: 253,
                        y: 167,
                        week_en: weekArr,
                        week_tc: weekArr,
                        week_sc: weekArr,
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,   
                    });
    
                    dateImg.setProperty(hmUI.prop.MORE,{
                        month_startX: 161,
                        month_startY: 167 ,
                        month_align: hmUI.align.LEFT,
                        month_space: 0,
                        month_zero: 1,
                        month_follow: 0,
                        month_is_character: false, 
                        month_en_array: dateWhiteArr,
                        month_sc_array: dateWhiteArr,
                        month_tc_array: dateWhiteArr,
                        month_unit_sc: rootPath + "img/white_dot.png",//单位
                        month_unit_tc: rootPath + "img/white_dot.png",//单位
                        month_unit_en:rootPath + "img/white_dot.png",//单位
                        
                        day_startX: 203,
                        day_startY: 167 ,
                        day_align: hmUI.align.LEFT,
                        day_space: 0,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateWhiteArr,
                        day_sc_array: dateWhiteArr,
                        day_tc_array: dateWhiteArr,
                        // day_is_character: true, 
                        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,   
                    });
                }
                function getCurrentDate()
                {
                    //传感器属性
                    //console.log("------------month: "+timeSensor.month+" day: "+timeSensor.day);
                    var currentDay= timeSensor.day; //currentDay=31;
                    var currentMonth=timeSensor.month;  
                    var countDown= 25-currentDay;
                    if(currentMonth==12 && (currentDay<=24))//1-24 倒计时
                    {
                        bgPath = "img/bg1.png";
                        day1.setProperty(hmUI.prop.VISIBLE,true);
                        day2.setProperty(hmUI.prop.VISIBLE,true);
                        showCountDown(countDown);
                        hideHeart(true,false);
                    }else if(currentMonth==12 && (currentDay>=25 && currentDay<=30)){ //25-30 节中
                        bgPath = "img/bg2.png";
                        hideCountDown();
                        hideHeart(true,false);
                    }else{
                        bgPath = "img/bg3.png";//12.31 ago----- 节后
                        hideCountDown();
                        hideHeart(false,true);
                    }
                    bg.setProperty(hmUI.prop.SRC,rootPath + bgPath);
                }
            
            
            function startCountDown(sec)
            {
                countDownTimer = timer.createTimer((60-sec)*1000+100, 1, (function (option) {
                    getCurrentDate();
                   // console.log(" hour: "+timeSensor.hour+"++++++++++++++++++++++++++++++++++++++++++++++++++++++currentSec："+timeSensor.second);
                    timer.stopTimer(countDownTimer);
                }));
            }
            function showCountDown(days)
            {
                var n1= parseInt(days/10) ;
                day1.setProperty(hmUI.prop.SRC,countArray[n1]);

                var n2= parseInt(days%10) ;
                day2.setProperty(hmUI.prop.SRC,countArray[n2]);
               // console.log(n1+" =n1"+ n2+"=n2 startCountDown-------------------count down days: "+days);

            }
           
            function hideCountDown()
            {
                day1.setProperty(hmUI.prop.VISIBLE,false);
                day2.setProperty(hmUI.prop.VISIBLE,false);
            }
            function showHeart()
            {
                heartIcon.setProperty(hmUI.prop.MORE,{
                    x: 202,
                    y: 29,
                    w: 32,
                    h: 32,
                    src:  rootPath + "img/heart.png",
                   // show_level: hmUI.show_level.ALL, 
                });
                heartTxt.setProperty(hmUI.prop.MORE,{
                    x: 240,
                    y: 33,
                    font_array: dateWhiteArr,   
                    h_space: 0,  
                    align_h: hmUI.align.CENTER_H,// hmUI.align.LEFT,
                    padding: false, //是否补零 true为补零
                    isCharacter: true, //true为文字图片
                    type: hmUI.data_type.HEART,   
                    invalid_image: rootPath + "img/invalid_white.png",
                    //show_level: hmUI.show_level.ALL,   
                });
               
                heartIcon3.setProperty(hmUI.prop.MORE,{
                    x: 42,//202,
                    y: 205,//29,
                    w: 32,
                    h: 32,
                    src:  rootPath + "img/heart.png",
                   // show_level: hmUI.show_level.ALL, 
                });
                heartTxt3.setProperty(hmUI.prop.MORE,{
                    x: 30,//240,
                    y: 240,//33,
                    font_array: dateWhiteArr,   
                    h_space: 0,  
                    align_h: hmUI.align.CENTER_H,// hmUI.align.LEFT,
                    padding: false, //是否补零 true为补零
                    isCharacter: true, //true为文字图片
                    type: hmUI.data_type.HEART,   
                    invalid_image: rootPath + "img/invalid_white.png",
                    //show_level: hmUI.show_level.ALL,   
                });
            }
            function hideHeart(bl1,bl2)
            {
                heartIcon.setProperty(hmUI.prop.VISIBLE,bl1);
                heartTxt.setProperty(hmUI.prop.VISIBLE,bl1);
                heartTxt3.setProperty(hmUI.prop.VISIBLE,bl2);
                heartIcon3.setProperty(hmUI.prop.VISIBLE,bl2);
            }
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    var hour = timeSensor.hour;
                    var min= timeSensor.minute;
                    var sec = timeSensor.second;
                    getCurrentDate(); 
                    if(timeSensor.month ==12 && (hour==23 || hour==11) &&  min == 59 && sec >=30)
                    {
                        startCountDown(sec);
                    }
                   // console.log(hour+" =hour"+ min+"=min resume_call-------------------timeSensor.month: "+timeSensor.month);
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    timer.stopTimer(countDownTimer);

                }),

            });

        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
       
            


        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
