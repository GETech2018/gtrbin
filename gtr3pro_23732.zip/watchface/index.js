﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_spo2_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 359,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 195,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0511.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 186,
              // start_y: 429,
              // color: 0xFFFF8C00,
              // pointer: 'pointer.png',
              // lenght: 107,
              // line_width: 0,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 437,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0314.png',
              unit_tc: '0314.png',
              unit_en: '0314.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 440,
              src: 'bat01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 387,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -2,
              invalid_image: '0312.png',
              dot_image: '0313.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 387,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -2,
              invalid_image: '0312.png',
              dot_image: '0313.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 387,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 308,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 294,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 134,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0311.png',
              unit_tc: '0311.png',
              unit_en: '0311.png',
              dot_image: '0310.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 180,
              center_y: 247,
              x: 155,
              y: 0,
              start_angle: -43,
              end_angle: 32,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 242,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 177,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 297,
              center_y: 247,
              x: -141,
              y: 0,
              start_angle: 30,
              end_angle: -33,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 260,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 137,
              week_en: ["wd01.png","wd02.png","wd03.png","wd04.png","wd05.png","wd06.png","wd07.png"],
              week_tc: ["wd01.png","wd02.png","wd03.png","wd04.png","wd05.png","wd06.png","wd07.png"],
              week_sc: ["wd01.png","wd02.png","wd03.png","wd04.png","wd05.png","wd06.png","wd07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 247,
              year_startY: 31,
              year_sc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              year_tc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              year_en_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              year_zero: 1,
              year_space: -4,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 208,
              month_startY: 31,
              month_sc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              month_tc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              month_en_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              month_zero: 1,
              month_space: -5,
              month_unit_sc: '0513.png',
              month_unit_tc: '0513.png',
              month_unit_en: '0513.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 31,
              day_sc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_tc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_en_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_zero: 1,
              day_space: -5,
              day_unit_sc: '0513.png',
              day_unit_tc: '0513.png',
              day_unit_en: '0513.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 62,
              hour_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 216,
              minute_startY: 62,
              minute_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 327,
              second_startY: 79,
              second_array: ["0600.png","0601.png","0602.png","0603.png","0604.png","0605.png","0606.png","0607.png","0608.png","0609.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 73,
              src: '0110.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 310,
              y: 73,
              src: '0110.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 137,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 344,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0512.png',
              unit_tc: '0512.png',
              unit_en: '0512.png',
              negative_image: '0510.png',
              invalid_image: '0511.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 344,
              font_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0512.png',
              unit_tc: '0512.png',
              unit_en: '0512.png',
              negative_image: '0510.png',
              invalid_image: '0511.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 327,
              font_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0512.png',
              unit_tc: '0512.png',
              unit_en: '0512.png',
              negative_image: '0510.png',
              invalid_image: '0511.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg02.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 62,
              hour_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 216,
              minute_startY: 62,
              minute_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 73,
              src: '0210.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hr3.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 180,
              hour_posY: 180,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 180,
              minute_posY: 180,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 186;
                  let start_y_normal_battery = 429;
                  let lenght_ls_normal_battery = 107;
                  let line_width_ls_normal_battery = 0;
                  let color_ls_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 8;
                  let pointer_offset_y_ls_normal_battery = 8;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  