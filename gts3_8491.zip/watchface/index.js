﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0C7627DB-6E5B-4090-93DA-60DA557288D7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 301,
              day_startY: 207,
              day_sc_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_tc_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_en_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '001.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 20,
              hour_posY: 123,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2EFF0139-F08C-40D2-8D00-332D64911CF5-removebg-preview.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 21,
              minute_posY: 165,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '002.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 17,
              second_posY: 160,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '7E671149-EB85-4D42-99BA-BF0BAD72CF36.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 301,
              day_startY: 207,
              day_sc_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_tc_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_en_array: ["00002.png","00003.png","00004.png","00005.png","00006.png","00007.png","00008.png","00009.png","00010.png","00011.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '001.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 20,
              hour_posY: 123,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2EFF0139-F08C-40D2-8D00-332D64911CF5-removebg-preview.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 21,
              minute_posY: 165,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '002.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 17,
              second_posY: 160,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  