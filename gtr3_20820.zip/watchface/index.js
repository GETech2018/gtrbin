﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 214,
              hour_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 114,
              minute_startY: 214,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 214,
              day_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_zero: 1,
              day_space: -3,
              day_unit_sc: '23.png',
              day_unit_tc: '23.png',
              day_unit_en: '23.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 369,
              month_startY: 214,
              month_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 260,
              y: 211,
              week_en: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_tc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_sc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 139,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 63,
              image_array: ["64.png"],
              image_length: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 359,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 278,
              image_array: ["62.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '109.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 26,
              hour_posY: 121,
              hour_cover_path: '108.png',
              hour_cover_x: 209,
              hour_cover_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '110.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 27,
              minute_posY: 194,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '111.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 26,
              second_posY: 196,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 149,
              hour_startY: 78,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 78,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 0,
              day_startY: 0,
              day_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 156,
              month_startY: 138,
              month_sc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_tc_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_en_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '23.png',
              month_unit_tc: '23.png',
              month_unit_en: '23.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 245,
              y: 138,
              week_en: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              week_tc: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              week_sc: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '109.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 26,
              hour_posY: 121,
              hour_cover_path: '108.png',
              hour_cover_x: 209,
              hour_cover_y: 209,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '110.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 27,
              minute_posY: 194,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  