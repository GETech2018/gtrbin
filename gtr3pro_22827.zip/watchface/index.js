﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 144,
              src: 'system_Blutoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 234,
              src: 'system_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 88,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 324,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act-W_Font_12.png',
              unit_tc: 'Act-W_Font_12.png',
              unit_en: 'Act-W_Font_12.png',
              negative_image: 'Act-W_Font_11.png',
              invalid_image: 'Act-W_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 318,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 332,
              month_sc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_tc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_en_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 400,
              week_en: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_tc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_sc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 332,
              day_sc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_tc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_en_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 291,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 124,
              y: 299,
              image_array: ["Batt_icons_01.png","Batt_icons_02.png","Batt_icons_03.png","Batt_icons_04.png","Batt_icons_05.png","Batt_icons_06.png","Batt_icons_07.png","Batt_icons_08.png","Batt_icons_09.png","Batt_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 140,
              font_array: ["HR_Font_01.png","HR_Font_02.png","HR_Font_03.png","HR_Font_04.png","HR_Font_05.png","HR_Font_06.png","HR_Font_07.png","HR_Font_08.png","HR_Font_09.png","HR_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 140,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 196,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'act_Font_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 196,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 226,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 242,
              y: 11,
              image_array: ["step_icons_01.png","step_icons_02.png","step_icons_03.png","step_icons_04.png","step_icons_05.png","step_icons_06.png","step_icons_07.png","step_icons_08.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 203,
              am_y: 64,
              am_sc_path: 'times_AM.png',
              am_en_path: 'times_AM.png',
              pm_x: 203,
              pm_y: 64,
              pm_sc_path: 'times_PM.png',
              pm_en_path: 'times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 336,
              hour_startY: 226,
              hour_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 399,
              minute_startY: 226,
              minute_array: ["TimeH_Font_01.png","TimeH_Font_02.png","TimeH_Font_03.png","TimeH_Font_04.png","TimeH_Font_05.png","TimeH_Font_06.png","TimeH_Font_07.png","TimeH_Font_08.png","TimeH_Font_09.png","TimeH_Font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 386,
              y: 226,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand-01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand-02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand-03.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 31,
              second_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 217,
              w: 53,
              h: 48,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 393,
              y: 225,
              w: 64,
              h: 27,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 224,
              w: 39,
              h: 32,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 75,
              w: 55,
              h: 47,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 314,
              w: 74,
              h: 45,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 133,
              w: 53,
              h: 53,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 134,
              w: 73,
              h: 53,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 251,
              w: 74,
              h: 32,
              src: 'A_E-Shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 144,
              src: 'system_Blutoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 234,
              src: 'system_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 227,
              y: 88,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 324,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act-W_Font_12.png',
              unit_tc: 'Act-W_Font_12.png',
              unit_en: 'Act-W_Font_12.png',
              negative_image: 'Act-W_Font_11.png',
              invalid_image: 'Act-W_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 318,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 332,
              month_sc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_tc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_en_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 400,
              week_en: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_tc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              week_sc: ["week_icons_01.png","week_icons_02.png","week_icons_03.png","week_icons_04.png","week_icons_05.png","week_icons_06.png","week_icons_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 174,
              day_startY: 332,
              day_sc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_tc_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_en_array: ["DATE_Font_01.png","DATE_Font_02.png","DATE_Font_03.png","DATE_Font_04.png","DATE_Font_05.png","DATE_Font_06.png","DATE_Font_07.png","DATE_Font_08.png","DATE_Font_09.png","DATE_Font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 291,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 124,
              y: 299,
              image_array: ["Batt_icons_01.png","Batt_icons_02.png","Batt_icons_03.png","Batt_icons_04.png","Batt_icons_05.png","Batt_icons_06.png","Batt_icons_07.png","Batt_icons_08.png","Batt_icons_09.png","Batt_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 140,
              font_array: ["HR_Font_01.png","HR_Font_02.png","HR_Font_03.png","HR_Font_04.png","HR_Font_05.png","HR_Font_06.png","HR_Font_07.png","HR_Font_08.png","HR_Font_09.png","HR_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 140,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 196,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'act_Font_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 196,
              font_array: ["act_Font_01.png","act_Font_02.png","act_Font_03.png","act_Font_04.png","act_Font_05.png","act_Font_06.png","act_Font_07.png","act_Font_08.png","act_Font_09.png","act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 226,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 242,
              y: 11,
              image_array: ["step_icons_01.png","step_icons_02.png","step_icons_03.png","step_icons_04.png","step_icons_05.png","step_icons_06.png","step_icons_07.png","step_icons_08.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 203,
              am_y: 64,
              am_sc_path: 'times_AM.png',
              am_en_path: 'times_AM.png',
              pm_x: 203,
              pm_y: 64,
              pm_sc_path: 'times_PM.png',
              pm_en_path: 'times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 336,
              hour_startY: 226,
              hour_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 399,
              minute_startY: 226,
              minute_array: ["TimeH_Font_01.png","TimeH_Font_02.png","TimeH_Font_03.png","TimeH_Font_04.png","TimeH_Font_05.png","TimeH_Font_06.png","TimeH_Font_07.png","TimeH_Font_08.png","TimeH_Font_09.png","TimeH_Font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 386,
              y: 226,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand-01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 195,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand-02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 195,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand-03.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 31,
              second_posY: 195,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  