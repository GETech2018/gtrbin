
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$week$_$week = ''
        let normal$_$date$_$img_date = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$temperature$_$jumpable$_$img_click = ''
        let normal$_$step$_$jumpable$_$img_click = ''
        let normal$_$pai$_$jumpable$_$img_click = ''
		let normal$_$heart$_$jumpable$_$img_click = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$week$_$week = ''
        let idle$_$date$_$img_date = ''
        let idle$_$analog_clock$_$time_pointer = ''
		
		let sec_pointer = null;
		let clock_timer = null
		var sec_offset = 0;
		var sec_old = 0;
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 186,
              y: 310,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 264,
              year_startY: 332,
              year_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_align: hmUI.align.LEFT,
              year_zero: 0,
              year_space: 0,
              year_is_character: false,
              month_startX: 228,
              month_startY: 332,
              month_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_unit_sc: '19.png',
              month_unit_tc: '19.png',
              month_unit_en: '19.png',
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 194,
              day_startY: 332,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_unit_sc: '20.png',
              day_unit_tc: '20.png',
              day_unit_en: '20.png',
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 356,
              src: '21.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 316,
              src: '22.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 316,
              src: '23.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 129,
              hour_path: '27.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 14,
              minute_posY: 194,
              minute_path: '28.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              //second_centerX: 240,
              //second_centerY: 240,
              //second_posX: 14,
              //second_posY: 220,
              //second_path: '29.png',
              //second_cover_path: '',
              //second_cover_x: 0,
              //second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,//display screen width
				h: 480,//display screen height
				pos_x: 240 - 14,
				pos_y: 240 - 220,
				center_x: 240,
				center_y: 240,
				angle: 0,
				src: "29.png",
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

                    
            normal$_$temperature$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 285,
              w: 110,
              h: 68,
              src: '24.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 376,
              w: 100,
              h: 100,
              src: '25.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 190,
              w: 100,
              h: 100,
              src: '26.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal$_$heart$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 376,
              y: 190,
              w: 100,
              h: 100,
              src: '26.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const time_naw = hmSensor.createSensor(hmSensor.id.TIME);
				
			clock_timer = timer.createTimer(0, 167, (function (option) {
				var sec = time_naw.second;
				if(sec != sec_old)
				{
					sec_offset = 0;                  
				}
				sec_old = sec;
				//sec = sec + sec_offset;
				sec_offset = sec_offset + 1;
				var angle = sec * 6 + sec_offset;
				sec_pointer.setProperty(hmUI.prop.ANGLE, angle);
			}));
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '30.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 186,
              y: 310,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 264,
              year_startY: 332,
              year_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              year_align: hmUI.align.LEFT,
              year_zero: 0,
              year_space: 0,
              year_is_character: false,
              month_startX: 228,
              month_startY: 332,
              month_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              month_unit_sc: '19.png',
              month_unit_tc: '19.png',
              month_unit_en: '19.png',
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 194,
              day_startY: 332,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_unit_sc: '20.png',
              day_unit_tc: '20.png',
              day_unit_en: '20.png',
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 129,
              hour_path: '27.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 14,
              minute_posY: 194,
              minute_path: '28.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
			
			const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				resume_call: (function () {
					var sec = time_naw.second;
					if(sec != sec_old)
					{
						sec_offset = 0;                  
					}
					sec_old = sec;
					//sec = sec + sec_offset;
					sec_offset = sec_offset + 1;
					var angle = sec * 6 + sec_offset;
					sec_pointer.setProperty(hmUI.prop.ANGLE, angle);
						
				}),
				pause_call: (function () {
					console.log('ui pause');
				}),

			});
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  