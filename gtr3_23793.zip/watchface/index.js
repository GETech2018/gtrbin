try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    // This next section is initialise clear vars
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const ASCII_START = 65; //A
        const rootPath = "images/";
        let worldCount = 0

        let img_bg = null
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''

        let normal_digital_clock_img_time = null;
        let idle_digital_clock_img_time = null;
        let world_clock = null;
        let timePointer = null;
        let worldPointer = null;
        let timeSec = null;
        let timeZone = null;
        let timeHourImg = null;
        let gmtImg = null;
        let dataArr = null;
        let timeArr = null;
  
        const cityArrayImg = new Array(3);
        const ASSIC_MAX_COUNT = 26;
        const ASCIIARRAY = new Array(ASSIC_MAX_COUNT);

        function setJsWidgetVisible(widget,visible){
            if(widget != null){
                widget.setProperty(hmUI.prop.VISIBLE, visible);
            }
        } //This is the code for setting citycode etc
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            
            showTimeZone(timeZoneHour) {
                var path = rootPath + "img/jian.png";
                if (timeZoneHour > 0) {
                    path = rootPath + "img/jia.png";
                } 
                var path2 = rootPath + "hour/" + Math.abs(timeZoneHour) + ".png";
                timeZone.setProperty(hmUI.prop.SRC, path);
                timeHourImg.setProperty(hmUI.prop.SRC, path2);
            },
            showCity(cityCode) {
                let index = 0;
                let maxWidth = 0;
                let path = 0;
                let sizeArray = new Array(3);
                if(cityCode=='undefined')
                {
                    cityCode="AAA";
                }
                for (let char of cityCode) {
                    const charCode = char.charCodeAt();
                    if (charCode < ASCII_START) {
                        continue;
                    }
                    if (index >= 3) {
                        break;
                    }
                    path = ASCIIARRAY[charCode - ASCII_START];
                    const imageInfo = hmUI.getImageInfo(path);
                    sizeArray[index] = imageInfo.width;
                    maxWidth += imageInfo.width;
                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);
                }
                const bMWidth = 132;
                const baseX = 142;
                let startX = baseX + (bMWidth - maxWidth) / 2;
                for (var i = 0; i < 3; i++) {
                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                    startX += sizeArray[i];
                }

            },
            setWorldAngle(hour,min) {
                //var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
                var angle = 15 * hour; //move on hour points
                worldPointer.setProperty(hmUI.prop.ANGLE, angle);

            },

            init_view() {
                let assicIndex = 0;
                for (var i = ASCII_START; i < ASCII_START + 26; i++) {
                    const path = rootPath + "cityCode/" + String.fromCharCode(i) + ".png";
                    ASCIIARRAY[assicIndex++] = path;
                 
                }
                dataArr = [
                    rootPath + "data/0.png",
                    rootPath + "data/1.png",
                    rootPath + "data/2.png",
                    rootPath + "data/3.png",
                    rootPath + "data/4.png",
                    rootPath + "data/5.png",
                    rootPath + "data/6.png",
                    rootPath + "data/7.png",
                    rootPath + "data/8.png",
                    rootPath + "data/9.png",
                ]

                timeArr = [
                    rootPath + "img/35.png",
                    rootPath + "img/36.png",
                    rootPath + "img/37.png",
                    rootPath + "img/38.png",
                    rootPath + "img/39.png",
                    rootPath + "img/40.png",
                    rootPath + "img/41.png",
                    rootPath + "img/42.png",
                    rootPath + "img/43.png",
                    rootPath + "img/44.png",
                ]

                // This section can modify for the various elements
                var screenType = hmSetting.getScreenType();

                world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: 0x000000,
                        show_level: hmUI.show_level.ONAL_AOD,
                    })

                } else {
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }   

                     gmtImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 0,
                        h: 0,
                        src: rootPath + "img/GMT.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 292,
                        y: 274,
                        font_array: dataArr,
                        padding: false,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 192,
                        y: 344,
                        font_array: dataArr,
                        padding: false,
                        h_space: 0,
                        align_h: hmUI.align.CENTER_H,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 248,
                        y: 136,
                        font_array: dataArr,
                        padding: false,
                        h_space: 0,
                        dot_image: rootPath + "img/18.png",
                        align_h: hmUI.align.RIGHT,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 105,
                        y: 136,
                        font_array: dataArr,
                        padding: false,
                        h_space: 0,
                        align_h: hmUI.align.LEFT,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 165,
                        y: 271,
                        image_array: [rootPath + "img/27.png",
                                      rootPath + "img/28.png",
                                      rootPath + "img/29.png",
                                      rootPath + "img/30.png",
                                      rootPath + "img/31.png",
                                      rootPath + "img/32.png",
                                      rootPath + "img/33.png",
                                      rootPath + "img/34.png"],  
                        image_length: 8,
                        type: hmUI.data_type.MOON,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                      normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 115,
                        day_startY: 305,
                        day_en_array: dataArr,
                        day_zero: 0,
                        day_space: 0,
                        day_align: hmUI.align.CENTER_H,
                        day_is_character: false,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                      normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 102,
                        y: 265,
                        week_en: [rootPath + "img/19.png",
                                  rootPath + "img/20.png",
                                  rootPath + "img/21.png",
                                  rootPath + "img/22.png",
                                  rootPath + "img/23.png",
                                  rootPath + "img/24.png",
                                  rootPath + "img/25.png"],
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }); 

                    //get from Zepp world clock - first city
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i] = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 160,
                            y: 80,
                            // w: 11,
                            // h: 28,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                    } // this city code
                    timeZone = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 80,
                        w: 18,
                        h: 32,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }); // this is plus or minus sign
                    timeHourImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 265,
                        y: 80,
                        w: 27,
                        h: 33,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    }); // this is the time zone in hours
                var noData = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 172,
                    y: 80,
                    w: 26,
                    h: 26,  
                    src: rootPath + "img/nodata.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
                noData.addEventListener(hmUI.event.CLICK_UP, (function (info) {    

                    hmApp.startApp({url:"WorldClockScreen",native:true});
                }));
               
                 worldPointer = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,//display screen width
                    h: 454,//display screen height
                    pos_x: 227 - 205,
                    pos_y: 227 - 205,
                    center_x: 227,
                    center_y: 227,
                    angle: 0,
                    src: rootPath + "img/worldPointer.png",
                }); 
                   
                world_clock.init();
                worldCount = world_clock.getWorldClockCount();
               
                if (worldCount >0) {
                    noData.setProperty(hmUI.prop.VISIBLE, false);
                    setJsWidgetVisible(worldPointer,true);
                    setJsWidgetVisible(timeZone,true);
                    setJsWidgetVisible(timeHourImg,true);
                    setJsWidgetVisible(gmtImg,true);
                    let worldData = world_clock.getWorldClockInfo(0); 
                    if (screenType != hmSetting.screen_type.AOD) {
                        this.showCity(worldData.cityCode);
                        //this.showCity("AKL");
                        this.showTimeZone(worldData.timeZoneHour);
                    }
                    this.setWorldAngle(worldData.hour,worldData.minute);
                } else {
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                    }
                    worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                    timeZone.setProperty(hmUI.prop.VISIBLE,false);
                    timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                    gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                    noData.setProperty(hmUI.prop.VISIBLE, true);
                }
                world_clock.uninit(); // this is for analog clocks etc
                if (screenType == hmSetting.screen_type.AOD) {
                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {

                        hour_centerX: 0,
                        hour_centerY: 0,
                        hour_posX: 0,
                        hour_posY: 0,
                        hour_path: rootPath + "img/hour.png",
                        hour_cover_path: rootPath + "img/min_cover.png",
                        hour_cover_x: 0,
                        hour_cover_y: 0,
                        show_level: hmUI.show_level.ONAL_AOD,
                    })               

                } else {
                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 0,
                        hour_centerY: 0,
                        hour_posX: 0,
                        hour_posY: 0,
                        hour_path: rootPath + "img/hour.png",
                        hour_cover_path: rootPath + "img/sec_cover.png",
                        hour_cover_x: 0,
                        hour_cover_y: 0,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }
                
                if (screenType == hmSetting.screen_type.AOD) {
                    idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 104,
                        hour_startY: 195,
                        hour_array: timeArr,
                        hour_zero: 1,
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 229,
                        minute_startY: 195,
                        minute_array: timeArr,
                        minute_zero: 1,
                        minute_space: 0,
                        minute_follow: 0,
                        minute_align: hmUI.align.LEFT,
                      
                        show_level: hmUI.show_level.ONAL_AOD,
                    })

                } else {
                    normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 104,
                        hour_startY: 195,
                        hour_array: timeArr,
                        hour_zero: 1,
                        hour_space: 0,
                        hour_align: hmUI.align.LEFT,

                        minute_startX: 229,
                        minute_startY: 195,
                        minute_array: timeArr,
                        minute_zero: 1,
                        minute_space: 0,
                        minute_follow: 0,
                        minute_align: hmUI.align.LEFT,

                        second_startX: 325,
                        second_startY: 194,
                        second_array: dataArr,
                        second_zero: 1,
                        second_space: 0,
                        second_follow: 0,
                        second_align: hmUI.align.LEFT,

                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }  

                const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () { 
                        world_clock.init();
                        worldCount = world_clock.getWorldClockCount();
                        if (worldCount > 0) {
                            noData.setProperty(hmUI.prop.VISIBLE, false);
                            worldPointer.setProperty(hmUI.prop.VISIBLE, true);
                            timeZone.setProperty(hmUI.prop.VISIBLE,true);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,true);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,true);
                            let worldData = world_clock.getWorldClockInfo(0);
                            var hour = worldData.hour;
                            var min =  worldData.minute;
                            //var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
                            var angle = 15 * hour;
                            worldPointer.setProperty(hmUI.prop.ANGLE, angle);
                            if (!(screenType == hmSetting.screen_type.AOD)) {
                                let index = 0;
                                let maxWidth = 0;
                                let path = 0;
                                let sizeArray = new Array(3);
                
                                for (let char of worldData.cityCode) {
                                    const charCode = char.charCodeAt();
                                    if (charCode < ASCII_START) {
                                        continue;
                                    }
                                    if (index >= 3) {
                                        break;
                                    }
                                    path = ASCIIARRAY[charCode - ASCII_START];
                                    const imageInfo = hmUI.getImageInfo(path);
                                    sizeArray[index] = imageInfo.width;
                                    maxWidth += imageInfo.width;
                                    cityArrayImg[index].setProperty(hmUI.prop.VISIBLE,true);
                                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);

                                }
                                const bMWidth = 132;
                                const baseX = 142;
                                let startX = baseX + (bMWidth - maxWidth) / 2;
                                for (var i = 0; i < 3; i++) {
                                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                                    startX += sizeArray[i];
                                }
                                // this.showTimeZone(worldData.timeZoneHour);
                                path = rootPath + "img/jian.png";
                                if (worldData.timeZoneHour > 0) {
                                    path = rootPath + "img/jia.png";
                                } 
                                var path2 = rootPath + "hour/" + Math.abs(worldData.timeZoneHour) + ".png";
                                timeZone.setProperty(hmUI.prop.SRC, path);
                                timeHourImg.setProperty(hmUI.prop.SRC, path2);
                            }
                        }else{
                            for (var i = 0; i < 3; i++) {
                                cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                            }
                            worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                            timeZone.setProperty(hmUI.prop.VISIBLE,false);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                            noData.setProperty(hmUI.prop.VISIBLE, true);
                        }
                        world_clock.uninit();
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();



            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke');
              
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
