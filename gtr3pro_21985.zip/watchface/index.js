﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_tag.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 396,
              day_startY: 233,
              day_sc_array: ["0000.png","0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
              day_tc_array: ["0000.png","0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
              day_en_array: ["0000.png","0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 321,
              y: 231,
              week_en: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              week_tc: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              week_sc: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 231,
              am_y: 328,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 236,
              pm_y: 328,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 289,
              hour_startY: 326,
              hour_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 354,
              minute_startY: 326,
              minute_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 332,
              src: '0027.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  