    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';
        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        //dynamic modify start
        let normal$_$background$_$bg = ''
		let normal$_$cityText$_$text$_$text = ''
		let normal$_$cityText$_$pointer_progress$_$img_pointer = ''
		let normal$_$battery$_$image_progress$_$img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        //let normal$_$humidity$_$text$_$text_img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
		let normal$_$system$_$disconnect$_$text = ''
		let normal$_$system$_$lock$_$text = ''
		let normal$_$system$_$clock$_$text = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
		
        let weatherSensor = null;
        

        const logger = DeviceRuntimeCore.HmLogger.getLogger("clock_face3_MIO");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
			
            //dynamic modify start
			
            weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		/*
    * Месторасположение
		*/
						
               normal$_$cityText$_$text$_$text = hmUI.widgetDelegate(hmUI.widget.TEXT, {										
                        x: 31,
                        y: 233,
                        w: 128,
                        h: 30,
						text_size: 22,
                        color: 0xfcfcfc,
                        
                        align_h: hmUI.align.CENTER_H,
                        align_v: hmUI.align.CENTER_V,
												});										
				   
				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			   resume_call: (function () {
         var cityName = weatherData.cityName.getForecastWeather();
         
         if (console.log('UI resume')
         );
              
			   normal$_$cityText$_$text$_$text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
			 }),
});


  /* const weatherData = weatherSensor.getForecastWeather();
     normal$_$cityText$_$text$_$text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
  */


            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 73,
              image_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 75,
              type: hmUI.data_type.BATTERY,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  unit_sc: '55.png',
              unit_tc: '55.png',
              unit_en: '55.png',
              padding: false,
              isCharacter: false
            });	 

 /*           normal$_$humidity$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 215,
              type: hmUI.data_type.HUMIDITY,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '74.png',
              unit_tc: '74.png',
              unit_en: '74.png',
              invalid_image: '71.png',
              padding: false,
              isCharacter: false
            });
*/			
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 180,
              image_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 270,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '52.png',
              unit_en: '52.png',
              negative_image: '51.png',
              invalid_image: '50.png',
              padding: false,
              isCharacter: false
            });

           normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 172,
              hour_startY: 170,
              hour_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 300,
              minute_startY: 170,
              minute_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 420,
              second_startY: 230,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  
            });   
			
			
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
			  year_startX: 340,
              year_startY: 295,
              year_sc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              year_tc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              year_en_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              year_align: hmUI.align.CENTER_H,
              year_zero: 1,
              year_space: 2,
              year_is_character: false,
              month_startX: 283,
              month_startY: 295,
              month_sc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              month_tc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              month_en_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              month_align: hmUI.align.CENTER_H,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 230,
              day_startY: 295,
              day_sc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              day_tc_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              day_en_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
			  
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 128,
              week_en: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              week_tc: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              week_sc: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                 

            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 340,
              type: hmUI.data_type.HEART,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '50.png',
              padding: false,
              isCharacter: false
            });

            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 340,
              type: hmUI.data_type.DISTANCE,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.LEFT,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '90.png', 
              invalid_image: '50.png',
              unit_sc: '49.png',
              unit_en: '49.png',			  
              padding: false,
              isCharacter: false
            });


            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 390,
              type: hmUI.data_type.STEP,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '71.png',
              padding: false,
              isCharacter: false
            });
			
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 390,
              type: hmUI.data_type.CAL,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });	

            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 74,
              src: '57.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 74,
              src: '53.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
              normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 74,
              src: '91.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  
            });

          idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '56.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 172,
              hour_startY: 170,
              hour_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,
              minute_zero: 1,
              minute_startX: 300,
              minute_startY: 170,
              minute_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
		
		
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }