
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$pointer_progress$_$img_pointer = ''
        let normal$_$step$_$jumpable$_$img_click = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$jumpable$_$img_click = ''
        let normal$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 23,
              hour_startY: 183,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 179,
              minute_startY: 183,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 340,
              second_startY: 225,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_space: 2,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 322,
              am_y: 260,
              am_en_path: '22.png',
              pm_x: 322,
              pm_y: 260,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 377,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 377,
              src: '25.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ALL,
            });


                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 337,
              y: 376,
              src: '113.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ALL,
            });


                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 218,
              src: '26.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 100,
              year_startY: 375,
              year_sc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              year_tc_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              year_en_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              year_align: hmUI.align.LEFT,
              year_zero: 1,
              year_space: 3,
              year_is_character: false,
              month_startX: 58,
              month_startY: 326,
              month_sc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              month_tc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              month_en_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 175,
              day_startY: 325,
              day_sc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_tc_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_en_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 1,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 326,
              week_en: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_tc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              week_sc: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 124,
              type: hmUI.data_type.STEP,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '56.png',
              center_x: 175,
              center_y: 116,
              x: 17,
              y: 41,
              type: hmUI.data_type.STEP,
              start_angle: 236,
              end_angle: 480,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$step$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 81,
              w: 30,
              h: 30,
              src: '57.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 125,
              type: hmUI.data_type.HEART,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ALL,
              invalid_image: '58.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'heart.png',
              center_x: 272,
              center_y: 117,
              x: 17,
              y: 41,
              type: hmUI.data_type.HEART,
              start_angle: 211,
              end_angle: 510,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 97,
              image_array: ["60.png","61.png","62.png","63.png","64.png","65.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 174,
              type: hmUI.data_type.BATTERY,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ALL,
              unit_sc: 'per.png',//单位
              unit_tc: 'per.png',//单位
              unit_en: 'per.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 53,
              type: hmUI.data_type.DISTANCE,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              unit_sc: 'km.png',//单位
              unit_tc: 'km.png',//单位
              unit_en: 'km.png',//单位
              dot_image: '76.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 53,
              type: hmUI.data_type.CAL,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 15,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ALL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 298,
              image_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 348,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ALL,
              unit_sc: '108.png',//单位
              unit_en: '109.png',//单位
              negative_image: '107.png', //负号图片
              invalid_image: '106.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 358,
              y: 305,
              w: 30,
              h: 30,
              src: '110.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 224,
              second_posY: 227,
              second_path: '112.png',
              second_cover_path: '111.png',
              second_cover_x: 159,
              second_cover_y: 151,
              show_level: hmUI.show_level.ALL,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  