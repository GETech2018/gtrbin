try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp;
    var n = e.current,
      { px: g } =
        (new DeviceRuntimeCore.WidgetFactory(
          new DeviceRuntimeCore.HmDomApi(e, n)
        ),
        e.app.__globals__);
    const t = Logger.getLogger("watchface6");
    n.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        var screenType = hmSetting.getScreenType();
        if(screenType == hmSetting.screen_type.AOD){
        
        }else{
            bg = hmUI.createWidget(hmUI.widget.IMG,{
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: "2.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                x: 0,
                y: 0,
                anim_path: "",
                anim_prefix: "first_anim",
                anim_ext: "png",
                anim_fps: 30,
                anim_size: 38,
                anim_repeat: false,
                repeat_count: 1,
                anim_status: 1,
                display_on_restart: true,
            });
        }

          hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: 370,
            hour_startY: 121,
            hour_array: [
              "3.png",
              "4.png",
              "5.png",
              "6.png",
              "7.png",
              "8.png",
              "9.png",
              "10.png",
              "11.png",
              "12.png",
            ],
            hour_space: 5,
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: 370,
            minute_startY: 190,
            minute_array: [
              "3.png",
              "4.png",
              "5.png",
              "6.png",
              "7.png",
              "8.png",
              "9.png",
              "10.png",
              "11.png",
              "12.png",
            ],
            minute_space: 5,
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 377,
            y: 261,
            type: hmUI.data_type.BATTERY,
            font_array: [
              "13.png",
              "14.png",
              "15.png",
              "16.png",
              "17.png",
              "18.png",
              "19.png",
              "20.png",
              "21.png",
              "22.png",
            ],
            align_h: hmUI.align.LEFT,
            h_space: 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
            unit_sc: "23.png",
            unit_tc: "23.png",
            unit_en: "23.png",
            padding: !1,
            isCharacter: !1,
          }),
          hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 300,
            y: 260,
            image_array: [
              "24.png",
              "25.png",
              "26.png",
              "27.png",
              "28.png",
              "29.png",
              "30.png",
              "31.png",
              "32.png",
              "33.png",
            ],
            image_length: 10,
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 313,
            y: 63,
            src: "34.png",
            type: hmUI.system_status.DISTURB,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 362,
            y: 67,
            src: "35.png",
            type: hmUI.system_status.CLOCK,
            show_level: hmUI.show_level.ONLY_NORMAL,
          }),
          hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: "36.png",
            show_level: hmUI.show_level.ONLY_AOD,
          }),
          hmUI.createWidget(hmUI.widget.IMG_TIME, {
            hour_zero: 1,
            hour_startX: 370,
            hour_startY: 121,
            hour_array: [
              "37.png",
              "38.png",
              "39.png",
              "40.png",
              "41.png",
              "42.png",
              "43.png",
              "44.png",
              "45.png",
              "46.png",
            ],
            hour_space: 5,
            hour_align: hmUI.align.LEFT,
            minute_zero: 1,
            minute_startX: 370,
            minute_startY: 190,
            minute_array: [
              "37.png",
              "38.png",
              "39.png",
              "40.png",
              "41.png",
              "42.png",
              "43.png",
              "44.png",
              "45.png",
              "46.png",
            ],
            minute_space: 5,
            minute_align: hmUI.align.LEFT,
            minute_follow: 0,
            show_level: hmUI.show_level.ONLY_AOD,
          }),
          hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 377,
            y: 261,
            type: hmUI.data_type.BATTERY,
            font_array: [
              "13.png",
              "14.png",
              "15.png",
              "16.png",
              "17.png",
              "18.png",
              "19.png",
              "20.png",
              "21.png",
              "22.png",
            ],
            align_h: hmUI.align.LEFT,
            h_space: 0,
            show_level: hmUI.show_level.ONLY_AOD,
            unit_sc: "23.png",
            unit_tc: "23.png",
            unit_en: "23.png",
            padding: !1,
            isCharacter: !1,
          }),
          hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 300,
            y: 260,
            image_array: [
              "47.png",
              "48.png",
              "49.png",
              "50.png",
              "51.png",
              "52.png",
              "53.png",
              "54.png",
              "55.png",
              "56.png",
            ],
            image_length: 10,
            type: hmUI.data_type.BATTERY,
            show_level: hmUI.show_level.ONLY_AOD,
          });
      },
      onInit() {
        t.log("index page.js on init invoke");
      },
      build() {
        this.init_view(), t.log("index page.js on ready invoke");
      },
      onDestory() {
        t.log("index page.js on destory invoke");
      },
    });
  })();
} catch (e) {
  console.log(e);
}