
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$week$_$week = ''
        let normal$_$date$_$img_date = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let normal$_$battery$_$pointer_progress$_$img_pointer = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$step$_$pointer_progress$_$img_pointer = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$week$_$week = ''
        let idle$_$date$_$img_date = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let idle$_$battery$_$pointer_progress$_$img_pointer = ''
        let idle$_$step$_$pointer_progress$_$img_pointer = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 425,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 390,
              day_startY: 227,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 0,
              day_follow: 0,
              day_space: 4,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 278,
              type: hmUI.data_type.HEART,
              font_array: ["19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '29.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '30.png',
              center_x: 240,
              center_y: 349,
              x: 9,
              y: 82,
              type: hmUI.data_type.HEART,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '31.png',
              center_x: 240,
              center_y: 131,
              x: 9,
              y: 54,
              type: hmUI.data_type.BATTERY,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 176,
              src: '32.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 272,
              src: '33.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 272,
              src: '34.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 400,
              y: 176,
              src: '35.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '36.png',
              center_x: 240,
              center_y: 131,
              x: 9,
              y: 82,
              type: hmUI.data_type.STEP,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 177,
              hour_path: '37.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 224,
              minute_path: '38.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
              second_posY: 231,
              second_path: '39.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '40.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 425,
              week_en: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_tc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              week_sc: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 390,
              day_startY: 227,
              day_sc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_tc_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_en_array: ["9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 0,
              day_follow: 0,
              day_space: 4,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 278,
              type: hmUI.data_type.HEART,
              font_array: ["19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '41.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '30.png',
              center_x: 240,
              center_y: 349,
              x: 9,
              y: 82,
              type: hmUI.data_type.HEART,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$battery$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '31.png',
              center_x: 240,
              center_y: 131,
              x: 9,
              y: 54,
              type: hmUI.data_type.BATTERY,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$step$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '36.png',
              center_x: 240,
              center_y: 131,
              x: 9,
              y: 82,
              type: hmUI.data_type.STEP,
              start_angle: 0,
              end_angle: 360,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 177,
              hour_path: '37.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 224,
              minute_path: '38.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  