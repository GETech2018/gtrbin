﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 262,
              y: 118,
              week_en: ["dow_01.png","dow_02.png","dow_03.png","dow_04.png","dow_05.png","dow_06.png","dow_07.png"],
              week_tc: ["dow_01.png","dow_02.png","dow_03.png","dow_04.png","dow_05.png","dow_06.png","dow_07.png"],
              week_sc: ["dow_01.png","dow_02.png","dow_03.png","dow_04.png","dow_05.png","dow_06.png","dow_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 336,
              month_startY: 86,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 288,
              day_startY: 81,
              day_sc_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              day_tc_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              day_en_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 342,
              y: 245,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 407,
              y: 246,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 322,
              font_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 87,
              y: 362,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 289,
              image_array: ["battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png","battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 322,
              font_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 42,
              font_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 394,
              font_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 109,
              font_array: ["data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png","data_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 152,
              image_array: ["step_1.png","step_2.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 175,
              hour_array: ["hour_01.png","hour_02.png","hour_03.png","hour_04.png","hour_05.png","hour_06.png","hour_07.png","hour_08.png","hour_09.png","hour_10.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 179,
              minute_startY: 175,
              minute_array: ["hour_01.png","hour_02.png","hour_03.png","hour_04.png","hour_05.png","hour_06.png","hour_07.png","hour_08.png","hour_09.png","hour_10.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 342,
              second_startY: 178,
              second_array: ["sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png","sec_10.png"],
              second_zero: 1,
              second_space: -5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 390,
              y: 235,
              w: 60,
              h: 50,
              src: 'transparent.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 315,
              w: 140,
              h: 100,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 25,
              w: 215,
              h: 60,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 90,
              w: 230,
              h: 65,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  