﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_year = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 395,
              src: 'UVI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 402,
              font_array: ["UV1.png","UV2.png","UV3.png","UV4.png","UV5.png","UV6.png","UV7.png","UV8.png","UV9.png","UVI.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 380,
              y: 220,
              src: 'bluetooth_rot.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 317,
              year_startY: 166,
              year_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              year_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              year_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 57,
              y: 248,
              src: 'barometer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 251,
              font_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hPa.png',
              unit_tc: 'hPa.png',
              unit_en: 'hPa.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 213,
              font_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 207,
              image_array: ["humidity.png"],
              image_length: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 41,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 288,
              font_array: ["bl10.png","bl11.png","bl12.png","bl13.png","bl14.png","bl15.png","bl16.png","bl17.png","bl18.png","bl19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 288,
              src: 'oxygen.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 360,
              w: 142,
              h: 28,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 113,
              font_array: ["r10.png","r11.png","r12.png","r13.png","r14.png","r15.png","r16.png","r17.png","r18.png","r19.png"],
              padding: false,
              h_space: 2,
              negative_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 118,
              src: '098.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 76,
              font_array: ["bl10.png","bl11.png","bl12.png","bl13.png","bl14.png","bl15.png","bl16.png","bl17.png","bl18.png","bl19.png"],
              padding: false,
              h_space: 0,
              negative_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 79,
              src: '097.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 98,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              padding: false,
              h_space: 1,
              unit_sc: 't018.png',
              unit_tc: 't018.png',
              unit_en: 't018.png',
              negative_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 166,
              y: 33,
              image_array: ["W0029.png","W0030.png","W0031.png","W0032.png","W0033.png","W0034.png","W0035.png","W0036.png","W0037.png","W0038.png","W0039.png","W0040.png","W0041.png","W0042.png","W0043.png","W0044.png","W0045.png","W0046.png","W0047.png","W0048.png","W0049.png","W0050.png","W0051.png","W0052.png","W0053.png","W0054.png","W0055.png","W0056.png","W0057.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 80,
              font_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 122,
              image_array: ["bat0097.png","bat0098.png","bat0099.png","bat0100.png","bat0101.png","bat0102.png","bat0103.png","bat0104.png","bat0105.png","bat0106.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 331,
              font_array: ["r10.png","r11.png","r12.png","r13.png","r14.png","r15.png","r16.png","r17.png","r18.png","r19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 333,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 165,
              day_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 166,
              month_sc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_tc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_en_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 166,
              week_en: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              week_tc: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              week_sc: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hours.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 9,
              hour_posY: 211,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minutes.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 9,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 9,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 222,
              hour_startY: 198,
              hour_array: ["C026.png","C027.png","C028.png","C029.png","C030.png","C031.png","C032.png","C033.png","C034.png","C035.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 220,
              minute_startY: 284,
              minute_array: ["C026.png","C027.png","C028.png","C029.png","C030.png","C031.png","C032.png","C033.png","C034.png","C035.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 336,
              second_startY: 265,
              second_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 80,
              font_array: ["bl10.png","bl11.png","bl12.png","bl13.png","bl14.png","bl15.png","bl16.png","bl17.png","bl18.png","bl19.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'blCelsius.png',
              unit_tc: 'blCelsius.png',
              unit_en: 'blCelsius.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 303,
              image_array: ["bat0097.png","bat0098.png","bat0099.png","bat0100.png","bat0101.png","bat0102.png","bat0103.png","bat0104.png","bat0105.png","bat0106.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 331,
              font_array: ["r10.png","r11.png","r12.png","r13.png","r14.png","r15.png","r16.png","r17.png","r18.png","r19.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 331,
              image_array: ["heartbeat.png","Hours.png","hPa.png","humidity.png","Minus.png","Minutes.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 99,
              day_startY: 189,
              day_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 90,
              month_startY: 236,
              month_sc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_tc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_en_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 88,
              y: 147,
              week_en: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              week_tc: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              week_sc: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 129,
              hour_array: ["C026.png","C027.png","C028.png","C029.png","C030.png","C031.png","C032.png","C033.png","C034.png","C035.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 188,
              minute_startY: 223,
              minute_array: ["C026.png","C027.png","C028.png","C029.png","C030.png","C031.png","C032.png","C033.png","C034.png","C035.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 218,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  