
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
		let normal$_$aqi$_$text$_$text_img = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
	    let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$high$_$text_img = ''
        let normal$_$temperature$_$low$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
	    let normal$_$sleep$_$text$_$text_img = ''
        let idle$_$digital_clock$_$img_time = ''
		let animCreate = null
		//dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
            var screenType = hmSetting.getScreenType();
			
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			if(screenType == hmSetting.screen_type.AOD){
				
			} else {
			    animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                        x: 133,
                        y: 207,
                        anim_path: "anim",
                        anim_prefix: "anim",
                        anim_ext: "png",
                        anim_fps: 18,
                        anim_size: 19,
                        anim_repeat: false,
                        repeat_count: 0,
                        anim_status: 1,
                        anim_complete_call:this._animNext,
                    });
				
			
			}
			
			normal$_$aqi$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 16,
              type: hmUI.data_type.AQI,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '41.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
			
			
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 55,
              hour_startY: 115,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_follow: 1,
              second_zero: 1,
              second_startX: 388,
              second_startY: 178,
              second_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 393,
              am_y: 132,
              am_en_path: '23.png',
			  am_path: '23.png',
              pm_x: 393,
              pm_y: 132,
              pm_en_path: '24.png',
			  pm_path: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 340,
              type: hmUI.data_type.HEART,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '25.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
         

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 340,
              type: hmUI.data_type.STEP,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
            
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 260,
              y: 50,
              image_array: ["59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 66,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '43.png',//单位
              unit_en: '43.png',//单位
              negative_image: '46.png', //负号图片
              invalid_image: '45.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
            normal$_$temperature$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 67,
              type: hmUI.data_type.WEATHER_LOW,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '99.png',//单位
              unit_en: '99.png',//单位
              negative_image: '46.png', //负号图片
              invalid_image: '45.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
          
            normal$_$temperature$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 67,
              type: hmUI.data_type.WEATHER_HIGH,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '43.png',//单位
              unit_en: '43.png',//单位
              negative_image: '42.png', //负号图片
              invalid_image: '41.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
                                
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 442,
              type: hmUI.data_type.DISTANCE,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '49.png', //小数点图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 396,
              type: hmUI.data_type.CAL,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 58,
              type: hmUI.data_type.BATTERY,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '50.png',//单位
              unit_tc: '50.png',//单位
              unit_en: '50.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 285,
              month_startY: 240,
              month_sc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              month_tc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              month_en_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              month_unit_sc: '51.png',
              month_unit_tc: '51.png',
              month_unit_en: '51.png',
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_sc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_tc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_en_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_zero: 1,
              day_follow: 1,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 390,
              y: 233,
              week_en: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              week_tc: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              week_sc: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
  
            normal$_$sleep$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 285,
              type: hmUI.data_type.SLEEP,
              font_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '49.png', //小数点图片
              padding: true,
              isCharacter: false
            });
            
            			
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 55,
              hour_startY: 115,
              hour_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              hour_space: 0,
              hour_unit_sc: '98.png',
              hour_unit_tc: '98.png',
              hour_unit_en: '98.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              minute_follow: 1,
              am_x: 393,
              am_y: 132,
              am_en_path: '23.png',
			  am_path: '23.png',
              pm_x: 393,
              pm_y: 132,
              pm_en_path: '24.png',
			  pm_path: '24.png',
			  show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  