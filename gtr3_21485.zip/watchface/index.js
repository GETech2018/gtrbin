﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_uvi_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Cadran_Circles_v02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aiguille_heures.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 45,
              hour_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aiguille_minutes.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 46,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'aiguille_secondes.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 46,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 129,
              hour_array: ["Heures_00.png","Heures_01.png","Heures_02.png","Heures_03.png","Heures_04.png","Heures_05.png","Heures_06.png","Heures_07.png","Heures_08.png","Heures_09.png"],
              hour_zero: 1,
              hour_space: -32,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 263,
              minute_startY: 229,
              minute_array: ["Minutes_00.png","Minutes_01.png","Minutes_02.png","Minutes_03.png","Minutes_04.png","Minutes_05.png","Minutes_06.png","Minutes_07.png","Minutes_08.png","Minutes_09.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 343,
              week_en: ["jours_01.png","jours_02.png","jours_03.png","jours_04.png","jours_05.png","jours_06.png","jours_07.png"],
              week_tc: ["jours_01.png","jours_02.png","jours_03.png","jours_04.png","jours_05.png","jours_06.png","jours_07.png"],
              week_sc: ["jours_01.png","jours_02.png","jours_03.png","jours_04.png","jours_05.png","jours_06.png","jours_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 154,
              font_array: ["Temp_00.png","Temp_01.png","Temp_02.png","Temp_03.png","Temp_04.png","Temp_05.png","Temp_06.png","Temp_07.png","Temp_08.png","Temp_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 343,
              month_sc_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_tc_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_en_array: ["mois_01.png","mois_02.png","mois_03.png","mois_04.png","mois_05.png","mois_06.png","mois_07.png","mois_08.png","mois_09.png","mois_10.png","mois_11.png","mois_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 341,
              day_sc_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              day_tc_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              day_en_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              day_zero: 0,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 93,
              font_array: ["Data_00.png","Data_01.png","Data_02.png","Data_03.png","Data_04.png","Data_05.png","Data_06.png","Data_07.png","Data_08.png","Data_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 93,
              font_array: ["Data_00.png","Data_01.png","Data_02.png","Data_03.png","Data_04.png","Data_05.png","Data_06.png","Data_07.png","Data_08.png","Data_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: -999,
              year_startY: -999,
              year_sc_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              year_tc_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              year_en_array: ["Days_00.png","Days_01.png","Days_02.png","Days_03.png","Days_04.png","Days_05.png","Days_06.png","Days_07.png","Days_08.png","Days_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 129,
              hour_array: ["Heures_00.png","Heures_01.png","Heures_02.png","Heures_03.png","Heures_04.png","Heures_05.png","Heures_06.png","Heures_07.png","Heures_08.png","Heures_09.png"],
              hour_zero: 1,
              hour_space: -32,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 263,
              minute_startY: 229,
              minute_array: ["Minutes_00.png","Minutes_01.png","Minutes_02.png","Minutes_03.png","Minutes_04.png","Minutes_05.png","Minutes_06.png","Minutes_07.png","Minutes_08.png","Minutes_09.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  