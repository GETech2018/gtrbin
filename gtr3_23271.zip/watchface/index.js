﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_circle_scale = ''
        let normal_fat_burning_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_countdown_jumpable_img_click = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 96,
              // line_width: 41,
              // color: 0xFF00E6FA,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 140,
              // line_width: 41,
              // color: 0xFFA0FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 184,
              // line_width: 41,
              // color: 0xFFFA1250,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '30.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 163,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '31.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 17,
              minute_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '32.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 12,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 189,
              w: 76,
              h: 76,
              src: 'a.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '30.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 163,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '31.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 17,
              minute_posY: 217,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale
                  // initial parameters
                  let start_angle_normal_stand = -90;
                  let end_angle_normal_stand = 270;
                  let center_x_normal_stand = 227;
                  let center_y_normal_stand = 227;
                  let radius_normal_stand = 96;
                  let line_width_cs_normal_stand = 41;
                  let color_cs_normal_stand = 0xFF00E6FA;
                  
                  // calculated parameters
                  let arcX_normal_stand = center_x_normal_stand - radius_normal_stand;
                  let arcY_normal_stand = center_y_normal_stand - radius_normal_stand;
                  let CircleWidth_normal_stand = 2 * radius_normal_stand;
                  let angle_offset_normal_stand = end_angle_normal_stand - start_angle_normal_stand;
                  angle_offset_normal_stand = angle_offset_normal_stand * progress_cs_normal_stand;
                  let end_angle_normal_stand_draw = start_angle_normal_stand + angle_offset_normal_stand;
                  
                  normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_stand,
                    y: arcY_normal_stand,
                    w: CircleWidth_normal_stand,
                    h: CircleWidth_normal_stand,
                    start_angle: start_angle_normal_stand,
                    end_angle: end_angle_normal_stand_draw,
                    color: color_cs_normal_stand,
                    line_width: line_width_cs_normal_stand,
                  });
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale
                  // initial parameters
                  let start_angle_normal_fat_burning = -90;
                  let end_angle_normal_fat_burning = 270;
                  let center_x_normal_fat_burning = 227;
                  let center_y_normal_fat_burning = 227;
                  let radius_normal_fat_burning = 140;
                  let line_width_cs_normal_fat_burning = 41;
                  let color_cs_normal_fat_burning = 0xFFA0FF00;
                  
                  // calculated parameters
                  let arcX_normal_fat_burning = center_x_normal_fat_burning - radius_normal_fat_burning;
                  let arcY_normal_fat_burning = center_y_normal_fat_burning - radius_normal_fat_burning;
                  let CircleWidth_normal_fat_burning = 2 * radius_normal_fat_burning;
                  let angle_offset_normal_fat_burning = end_angle_normal_fat_burning - start_angle_normal_fat_burning;
                  angle_offset_normal_fat_burning = angle_offset_normal_fat_burning * progress_cs_normal_fat_burning;
                  let end_angle_normal_fat_burning_draw = start_angle_normal_fat_burning + angle_offset_normal_fat_burning;
                  
                  normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_fat_burning,
                    y: arcY_normal_fat_burning,
                    w: CircleWidth_normal_fat_burning,
                    h: CircleWidth_normal_fat_burning,
                    start_angle: start_angle_normal_fat_burning,
                    end_angle: end_angle_normal_fat_burning_draw,
                    color: color_cs_normal_fat_burning,
                    line_width: line_width_cs_normal_fat_burning,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 270;
                  let center_x_normal_calorie = 227;
                  let center_y_normal_calorie = 227;
                  let radius_normal_calorie = 184;
                  let line_width_cs_normal_calorie = 41;
                  let color_cs_normal_calorie = 0xFFFA1250;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  