
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$component_0$_$component = ''
        let normal$_$step$_$current$_$component_0$_$text_img = ''
        let normal$_$step$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$battery$_$text$_$component_0$_$text_img = ''
        let normal$_$battery$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$heart_rate$_$text$_$component_0$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$calorie$_$current$_$component_0$_$text_img = ''
        let normal$_$calorie$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$pai$_$weekly$_$component_0$_$text_img = ''
        let normal$_$pai$_$pointer_progress$_$component_0$_$img_pointer = ''
        let normal$_$component_1$_$component = ''
        let normal$_$battery$_$text$_$component_1$_$text_img = ''
        let normal$_$battery$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$heart_rate$_$text$_$component_1$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$calorie$_$current$_$component_1$_$text_img = ''
        let normal$_$calorie$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$pai$_$weekly$_$component_1$_$text_img = ''
        let normal$_$pai$_$pointer_progress$_$component_1$_$img_pointer = ''
        let normal$_$component$_$cover = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let normal$_$component$_$mask = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end
        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
            "anim_rate": 'linear',
            "anim_duration": animDuration,
            "anim_from": 0,
            "anim_to": 360,
            "repeat_count": 1,
            "anim_fps": 25,
            "anim_key": "angle",
            "anim_status": 1,
        }
        /**
         * 在合适的层级调用此方法即可
         */
        function setSec() {
            if (now == null) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            var screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
                stopSecAnim();
            } else {
                secondPic = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    pos_x: 454 / 2 - 9,
                    pos_y: 454 / 2 - 219,
                    center_x: 227,
                    center_y: 227,
                    src:  "59.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
            }
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {//划入表盘
                    console.log('ui resume');
                    if (timer_sec_anim != null && timer_sec_anim != 0) return;
                    let duration = now.utc - lastTime;
                    if (duration < animDuration) {
                        duration = animDuration - duration;
                    } else {
                        duration = 0;
                    }
                    timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
                        lastTime = now.utc;
                        startSecAnim();
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim() {
            let sec = now.second * 6;
            secAnim["anim_from"] = sec;
            secAnim["anim_to"] = sec + animDuration * 6 / 1000;

            secondPic.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()中要调用一下这个方法
         */
        function stopSecAnim() {
            timer.stopTimer(timer_sec_anim);
            timer_sec_anim = 0;
        }
        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
              edit_id: 0,
              x: 152,
              y: 44,
              w: 158,
              h: 158,
              select_image: '2.png',
              un_select_image: '3.png',
              default_type: hmUI.edit_type.PAI,
              optional_types: [{"type":hmUI.edit_type.PAI,"preview":"5.png"},{"type":hmUI.edit_type.STEP,"preview":"6.png"},{"type":hmUI.edit_type.BATTERY,"preview":"7.png"},{"type":hmUI.edit_type.CAL,"preview":"8.png"},{"type":hmUI.edit_type.HEART,"preview":"9.png"}],
              count: 5,
              tips_BG: '4.png',
              tips_x: 17,
              tips_y: 163,
              tips_width: 122,
            });
  
                    
            editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
        
            switch (editType) {
              case hmUI.edit_type.STEP:
                            
                normal$_$step$_$current$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 205,
                  y: 148,
                  type: hmUI.data_type.STEP,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '20.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$step$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '22.png',
                  center_x: 227,
                  center_y: 119,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.STEP,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 44,
                  scale_sc: '21.png',
                  scale_tc: '21.png',
                  scale_en: '21.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.BATTERY:
                            
                normal$_$battery$_$text$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 148,
                  type: hmUI.data_type.BATTERY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  unit_sc: '24.png',//单位
                  unit_tc: '24.png',//单位
                  unit_en: '24.png',//单位
                  invalid_image: '23.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$battery$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '26.png',
                  center_x: 227,
                  center_y: 119,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.BATTERY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 44,
                  scale_sc: '25.png',
                  scale_tc: '25.png',
                  scale_en: '25.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.HEART:
                            
                normal$_$heart_rate$_$text$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 148,
                  type: hmUI.data_type.HEART,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '27.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$heart_rate$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '29.png',
                  center_x: 227,
                  center_y: 119,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.HEART,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 44,
                  scale_sc: '28.png',
                  scale_tc: '28.png',
                  scale_en: '28.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.CAL:
                            
                normal$_$calorie$_$current$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 148,
                  type: hmUI.data_type.CAL,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '30.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$calorie$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '32.png',
                  center_x: 227,
                  center_y: 119,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.CAL,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 44,
                  scale_sc: '31.png',
                  scale_tc: '31.png',
                  scale_en: '31.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.PAI:
                            
                normal$_$pai$_$weekly$_$component_0$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 148,
                  type: hmUI.data_type.PAI_WEEKLY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '33.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$pai$_$pointer_progress$_$component_0$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '35.png',
                  center_x: 227,
                  center_y: 119,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.PAI_WEEKLY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 44,
                  scale_sc: '34.png',
                  scale_tc: '34.png',
                  scale_en: '34.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.DISTANCE:
                break;
              case hmUI.edit_type.AQI:
                break;
              case hmUI.edit_type.HUMIDITY:
                break;
              case hmUI.edit_type.UVI:
                break;
              case hmUI.edit_type.DATE:
                break;
              case hmUI.edit_type.WEEK:
                break;
              case hmUI.edit_type.WEATHER:
                break;
              case hmUI.edit_type.TEMPERATURE:
                break;
              case hmUI.edit_type.SUN:
                break;
              default:
                break
            }
  
                    
            normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,{
              edit_id: 1,
              x: 152,
              y: 260,
              w: 158,
              h: 158,
              select_image: '36.png',
              un_select_image: '37.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [{"type":hmUI.edit_type.HEART,"preview":"39.png"},{"type":hmUI.edit_type.BATTERY,"preview":"40.png"},{"type":hmUI.edit_type.CAL,"preview":"41.png"},{"type":hmUI.edit_type.PAI,"preview":"42.png"}],
              count: 4,
              tips_BG: '38.png',
              tips_x: 17,
              tips_y: -53,
              tips_width: 122,
            });
  
                    
            editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
        
            switch (editType) {
              case hmUI.edit_type.STEP:
                break;
              case hmUI.edit_type.BATTERY:
                            
                normal$_$battery$_$text$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 364,
                  type: hmUI.data_type.BATTERY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  unit_sc: '44.png',//单位
                  unit_tc: '44.png',//单位
                  unit_en: '44.png',//单位
                  invalid_image: '43.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$battery$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '46.png',
                  center_x: 227,
                  center_y: 335,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.BATTERY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 261,
                  scale_sc: '45.png',
                  scale_tc: '45.png',
                  scale_en: '45.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.HEART:
                            
                normal$_$heart_rate$_$text$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 364,
                  type: hmUI.data_type.HEART,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '47.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$heart_rate$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '49.png',
                  center_x: 227,
                  center_y: 335,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.HEART,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 261,
                  scale_sc: '48.png',
                  scale_tc: '48.png',
                  scale_en: '48.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.CAL:
                            
                normal$_$calorie$_$current$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 210,
                  y: 361,
                  type: hmUI.data_type.CAL,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '50.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$calorie$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '52.png',
                  center_x: 227,
                  center_y: 335,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.CAL,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 261,
                  scale_sc: '51.png',
                  scale_tc: '51.png',
                  scale_en: '51.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.PAI:
                            
                normal$_$pai$_$weekly$_$component_1$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 214,
                  y: 361,
                  type: hmUI.data_type.PAI_WEEKLY,
                  font_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
                  align_h: hmUI.align.CENTER_H,
                  h_space: 0,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  invalid_image: '53.png',// 无数据时显示的图片
                  padding: false,
                  isCharacter: false
                });
  
                            
                normal$_$pai$_$pointer_progress$_$component_1$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                  src: '55.png',
                  center_x: 227,
                  center_y: 335,
                  x: 6,
                  y: 58,
                  type: hmUI.data_type.PAI_WEEKLY,
                  start_angle: 0,
                  end_angle: 360,
                  cover_path: '',
                  cover_x: 0,
                  cover_y: 0,
                  scale_x: 152,
                  scale_y: 261,
                  scale_sc: '54.png',
                  scale_tc: '54.png',
                  scale_en: '54.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
  
                break;
              case hmUI.edit_type.DISTANCE:
                break;
              case hmUI.edit_type.AQI:
                break;
              case hmUI.edit_type.HUMIDITY:
                break;
              case hmUI.edit_type.UVI:
                break;
              case hmUI.edit_type.DATE:
                break;
              case hmUI.edit_type.WEEK:
                break;
              case hmUI.edit_type.WEATHER:
                break;
              case hmUI.edit_type.TEMPERATURE:
                break;
              case hmUI.edit_type.SUN:
                break;
              default:
                break
            }
  
                    
            normal$_$component$_$cover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK,{
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '56.png',
              show_level:hmUI.show_level.ONLY_EDIT,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 10,
              hour_posY: 146,
              hour_path: '57.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 14,
              minute_posY: 210,
              minute_path: '58.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
            setSec();
                    
            normal$_$component$_$mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK,{
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '60.png',
              show_level:hmUI.show_level.ONLY_EDIT,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 10,
              hour_posY: 146,
              hour_path: '57.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 14,
              minute_posY: 210,
              minute_path: '58.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  