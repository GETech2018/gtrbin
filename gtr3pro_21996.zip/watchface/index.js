
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$sun$_$high$_$text_img = ''
        let normal$_$sun$_$low$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$analog_clock$_$time_pointer = '' 
        let normal_moon_image_progress_img_level = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$step$_$current$_$text_img = ''
        let idle$_$step$_$image_progress$_$img_level = ''
        let idle$_$calorie$_$current$_$text_img = ''
        let idle$_$distance$_$text$_$text_img = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$pointer_progress$_$img_pointer = ''
        let idle$_$weather$_$image_progress$_$img_level = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$temperature$_$current$_$text_img = ''
        let idle$_$sun$_$high$_$text_img = ''
        let idle$_$sun$_$low$_$text_img = ''
        let idle$_$battery$_$text$_$text_img = ''
        let idle$_$battery$_$image_progress$_$img_level = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 132,
              hour_startY: 340,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 244,
              minute_startY: 340,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 4,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 340,
              second_startY: 341,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_space: 4,
              second_align: hmUI.align.CENTER_H,
              second_follow: 0,
              am_x: 335,
              am_y: 374,
              am_en_path: '22.png',
              pm_x: 335,
              pm_y: 374,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 205,
              type: hmUI.data_type.STEP,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 254,
              image_array: ["34.png","35.png","36.png","37.png","38.png","39.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 160,
              type: hmUI.data_type.CAL,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 118,
              type: hmUI.data_type.DISTANCE,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '40.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 262,
              type: hmUI.data_type.HEART,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '41.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '42.png',
              center_x: 104,
              center_y: 240,
              x: 7,
              y: 52,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 245,
              image_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 143,
              month_startY: 16,
              month_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 212,
              day_startY: 70,
              day_sc_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_tc_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_en_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 4,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 204,
              y: 124,
              week_en: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              week_tc: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              week_sc: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 255,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '113.png',//单位
              unit_en: '114.png',//单位
              negative_image: '112.png', //负号图片
              invalid_image: '111.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 291,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '126.png', //小数点图片
              invalid_image: '125.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 291,
              type: hmUI.data_type.SUN_SET,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '128.png', //小数点图片
              invalid_image: '127.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 420,
              type: hmUI.data_type.BATTERY,
              font_array: ["129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '139.png',//单位
              unit_tc: '139.png',//单位
              unit_en: '139.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 330,
              image_array: ["140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 37,
              y: 355,
              src: '150.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 448,
              y: 275,
              src: '151.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 376,
              y: 374,
              src: '152.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 240,
              second_path: '153.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

  
            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 334,
              y: 56,
              image_array: ["moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '154.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 132,
              hour_startY: 340,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 244,
              minute_startY: 340,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 4,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              am_x: 335,
              am_y: 374,
              am_en_path: '22.png',
              pm_x: 335,
              pm_y: 374,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 205,
              type: hmUI.data_type.STEP,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 254,
              image_array: ["34.png","35.png","36.png","37.png","38.png","39.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 160,
              type: hmUI.data_type.CAL,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 118,
              type: hmUI.data_type.DISTANCE,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '40.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 262,
              type: hmUI.data_type.HEART,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '41.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$pointer_progress$_$img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '42.png',
              center_x: 104,
              center_y: 240,
              x: 7,
              y: 52,
              type: hmUI.data_type.HEART,
              start_angle: -120,
              end_angle: 120,
              cover_path: '',
              cover_x: 0,
              cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 245,
              image_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 143,
              month_startY: 16,
              month_sc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_tc_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_en_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 212,
              day_startY: 70,
              day_sc_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_tc_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_en_array: ["84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 4,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 204,
              y: 124,
              week_en: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              week_tc: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              week_sc: ["94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 255,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '113.png',//单位
              unit_en: '114.png',//单位
              negative_image: '112.png', //负号图片
              invalid_image: '111.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 291,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '126.png', //小数点图片
              invalid_image: '125.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 291,
              type: hmUI.data_type.SUN_SET,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '128.png', //小数点图片
              invalid_image: '127.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 420,
              type: hmUI.data_type.BATTERY,
              font_array: ["129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '139.png',//单位
              unit_tc: '139.png',//单位
              unit_en: '139.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 330,
              image_array: ["140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  