
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$distance$_$icon$_$img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$date$_$img_date = ''
        let normal$_$date$_$day$_$separator_img = ''
        let normal$_$week$_$week = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$current$_$separator_img = ''
	let normal$_$temperature$_$jumpable$_$img_click = ''
        let normal$_$step$_$jumpable$_$img$_$click = ''
        let normal$_$countdown$_$jumpable$_$img$_$click = ''
        let normal$_$stopwatch$_$jumpable$_$img$_$click = ''
        let normal$_$heart$_$jumpable$_$img$_$click = ''
        let normal$_$alarm$_$jumpable$_$img$_$click = ''
	let normal$_$distance$_$jumpable$_$img$_$click = ''
	let normal$_$calorie$_$jumpable$_$img$_$click = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$digital_clock$_$hour$_$separator_img = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 3,
              hour_startY: 180,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 154,
              minute_startY: 180,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 309,
              second_startY: 184,
              second_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 24,
              type: hmUI.data_type.HEART,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '42.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 100,
              type: hmUI.data_type.STEP,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 308,
              type: hmUI.data_type.DISTANCE,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '64.png',//单位
              unit_tc: '64.png',//单位
              unit_en: '64.png',//单位
              dot_image: '63.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$icon$_$img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 435,
              src: '65.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 379,
              type: hmUI.data_type.CAL,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 327,
              type: hmUI.data_type.BATTERY,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '86.png',//单位
              unit_tc: '86.png',//单位
              unit_en: '86.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 291,
              image_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 323,
              month_startY: 94,
              month_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 0,
              month_is_character: false,
              day_startX: 249,
              day_startY: 94,
              day_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$date$_$day$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 107,
              w: 9,
              h: 42,
              src: '118.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 286,
              y: 56,
              week_en: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              week_tc: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              week_sc: ["119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 325,
              y: 12,
              src: '126.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 13,
              src: '127.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });              

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 331,
              y: 248,
              src: '128.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 383,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              negative_image: '140.png', //负号图片
              invalid_image: '139.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$current$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 383,
              w: 23,
              h: 29,
              src: '141.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$temperature$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 364,
              w: 120,
              h: 65,
              src: '163.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });          

	    normal$_$countdown$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 175,
              w: 120,
              h: 90,
              src: '163.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$stopwatch$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 175,
              w: 120,
              h: 90,
              src: '163.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$alarm$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 220,
              w: 80,
              h: 60,
              src: '163.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 	          
	    normal$_$heart$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 14,
              w: 170,
              h: 63,
              src: '163.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal$_$step$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 90,
              w: 183,
              h: 63,
              src: '163.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$distance$_$jumpable$_$img$_$click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 304,
              w: 178,
              h: 56,
              src: '163.png',
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$pai$_$jumpable$_$img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 376,
              w: 178,
              h: 56,
              src: '163.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 53,
              hour_startY: 180,
              hour_array: ["142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png","151.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 219,
              minute_startY: 180,
              minute_array: ["142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png","151.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$hour$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 193,
              w: 20,
              h: 58,
              src: '162.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  