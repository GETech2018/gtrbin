
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$animation$_$first = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 41,
              hour_startY: 128,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 12,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 178,
              minute_startY: 128,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 12,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 298,
              second_startY: 160,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_space: 9,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 22,
              year_startY: 365,
              year_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              year_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              year_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              year_align: hmUI.align.CENTER_H,
              year_zero: 1,
              year_space: 4,
              year_is_character: false,
              month_startX: 140,
              month_startY: 365,
              month_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              month_align: hmUI.align.RIGHT,
              month_zero: 0,
              month_follow: 0,
              month_space: 5,
              month_is_character: false,
              day_startX: 211,
              day_startY: 365,
              day_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 0,
              day_follow: 0,
              day_space: 5,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 302,
              y: 365,
              week_en: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_tc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              week_sc: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 260,
              type: hmUI.data_type.HEART,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 5,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '39.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 260,
              type: hmUI.data_type.CAL,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 313,
              type: hmUI.data_type.DISTANCE,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '40.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 313,
              type: hmUI.data_type.STEP,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 10,
              y: 82,
              type: hmUI.data_type.BATTERY,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '41.png',//单位
              unit_tc: '41.png',//单位
              unit_en: '41.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 82,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '44.png',//单位
              negative_image: '43.png', //负号图片
              invalid_image: '42.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$animation$_$first = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 130,
              y: 222,
              anim_path: '',
              anim_prefix: 'first_anim',
              anim_ext: 'png',
              anim_fps: 10,
              anim_size: 9,
              anim_repeat: true,
              repeat_count: 255,
              anim_status: hmUI.anim_status.START,
            });

                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 119,
              y: 91,
              src: '45.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 91,
              src: '46.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 172,
              y: 91,
              src: '47.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 41,
              hour_startY: 128,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 12,
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_startX: 178,
              minute_startY: 128,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 12,
              minute_align: hmUI.align.CENTER_H,
              minute_follow: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  