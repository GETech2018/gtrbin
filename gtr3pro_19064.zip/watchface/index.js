try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let timeRootPath = null
    let animType = null
    let animDuration = null
    let timeArray = null
    let stepArray = null
    let bg = null
    let animCreate = null
    let animResident = null
    let minuteHigh = null
    let minuteLow = null
    let hourHigh = null
    let hourLow = null
    let ampm = null
    let stepText = null
    let hourDelay = null
    let minuteDelay = null
    let clock_timer = null
    let timeSensor = null;

    const logger = DeviceRuntimeCore.HmLogger.getLogger("default2");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

        _animNext() {
            //animResident.setProperty(hmUI.prop.ANIM_STATUS,1);
            //animCreate.setProperty(hmUI.prop.VISIBLE,false);
        },

        init_view() {
            timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            rootPath = "images/",
            timeRootPath = rootPath + "time/"
            animType = "easein";
            animDuration = 1000;
            timeArray = [
                "time_0.png",
                "time_1.png",
                "time_2.png",
                "time_3.png",
                "time_4.png",
                "time_5.png",
                "time_6.png",
                "time_7.png",
                "time_8.png",
                "time_9.png",
            ]
            stepArray = [rootPath + "step/step_num_0.png",
                rootPath + "step/step_num_1.png",
                rootPath + "step/step_num_2.png",
                rootPath + "step/step_num_3.png",
                rootPath + "step/step_num_4.png",
                rootPath + "step/step_num_5.png",
                rootPath + "step/step_num_6.png",
                rootPath + "step/step_num_7.png",
                rootPath + "step/step_num_8.png",
                rootPath + "step/step_num_9.png",
            ]
            var alpha = 0;
            var screenType = hmSetting.getScreenType();
            if(screenType == hmSetting.screen_type.AOD){
                alpha = 255;
            }
            bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                color: 0x000000,
            });
            
            if(screenType != hmSetting.screen_type.AOD){
                animCreate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: rootPath + "anim",
                    anim_prefix: "anim",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 103,
                    anim_repeat: false,
                    repeat_count: 0,
                    anim_status: 1,
                    anim_complete_call:this._animNext,
                });
                //animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
                //animResident.setProperty(hmUI.prop.MORE, {
                //    x: 0,
                //    y: 0,
                //    anim_path: rootPath + "anim_1",
                //    anim_prefix: "anim",
                //    anim_ext: "png",
                //    anim_fps: 23,
                //    anim_size: 45,
                //    anim_repeat: true,
                //    repeat_count: 1,
				//
                //});
            }
            
            minuteHigh = hmUI.createWidget(hmUI.widget.IMG, {
                x: 158,
                y: 218,
                w: 112,
                h: 136,
                alpha: alpha,
                src: timeRootPath + timeArray[1],
                show_level:hmUI.show_level.ALL,
            });
            minuteLow = hmUI.createWidget(hmUI.widget.IMG, {
                x: 228,
                y: 218,
                w: 112,
                h: 136,
                alpha: alpha,
                src: timeRootPath + timeArray[5],
                show_level:hmUI.show_level.ALL,
            });

            hourHigh = hmUI.createWidget(hmUI.widget.IMG, {
                x: 112,
                y: 123,
                w: 112,
                h: 136,
                alpha: alpha,
                src: timeRootPath + timeArray[0],
                show_level:hmUI.show_level.ALL,
            });
            hourLow = hmUI.createWidget(hmUI.widget.IMG, {
                x: 182,
                y: 123,
                w: 112,
                h: 136,
                alpha: alpha,
                src: timeRootPath + timeArray[8],
                show_level:hmUI.show_level.ALL,
            });
            ampm = hmUI.createWidget(hmUI.widget.IMG_TIME,{
                show_level:hmUI.show_level.ALL,
                am_x: 266,
                am_y: 191,
                pm_x: 266,
                pm_y: 191,
                am_sc_path: rootPath + "ampm/am_cn.png",
                am_en_path: rootPath + "ampm/am_en.png",
                pm_sc_path: rootPath + "ampm/pm_cn.png",
                pm_en_path: rootPath + "ampm/pm_en.png",
                alpha:alpha,
            });
           

            stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                icon:rootPath + "icon/ico_step.png",
                icon_space:16,
                show_level:hmUI.show_level.ALL,
                x: 0,
                y: 404,
                w:480,
                h:41,
                type: hmUI.data_type.STEP,
                font_array: stepArray,
                h_space: 0,
                align_h: hmUI.align.CENTER_H,
                alpha: alpha,
            });
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');
                    minuteHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.minute/10)]);
                    minuteLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.minute%10)]);
                    
                    hourHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.format_hour/10)]);
                    hourLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.format_hour%10)]);
                }),
                pause_call: (function () {
                    console.log('ui pause');
                }),

            });
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();
            minuteHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.minute/10)]);
            minuteLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.minute%10)]);
            
            hourHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.format_hour/10)]);
            hourLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(timeSensor.format_hour%10)]);
            var screenType = hmSetting.getScreenType();
            if(screenType != hmSetting.screen_type.AOD){
            hourDelay = timer.createTimer(480, 500, (function (unknow) {
                console.log("hour callback");
                timer.stopTimer(hourDelay);
                hourHigh.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });
                hourLow.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });

                ampm.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });


                stepText.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });
            }), {});

            minuteDelay = timer.createTimer(520, 500, (function (unknow) {
                console.log("hour callback");
                timer.stopTimer(minuteDelay);
                minuteHigh.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });
                minuteLow.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": animType,
                    "anim_duration": animDuration,
                    "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 25,
                    "anim_key": "alpha",
                });

            }), {});
           }
           var repleatTime = 1000;
           var delayTime = 10;
            if (screenType == hmSetting.screen_type.AOD) {
                repleatTime = 1000 * 60;
                delayTime = 10;
            }
            clock_timer = timer.createTimer(delayTime, repleatTime, (function (option) {
                // console.log("timer callback");

                var now_hour = timeSensor.format_hour;
                var now_minute = timeSensor.minute;
                
                minuteHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(now_minute/10)]);
                minuteLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(now_minute%10)]);
                
                hourHigh.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(now_hour/10)]);
                hourLow.setProperty(hmUI.prop.SRC,timeRootPath+timeArray[parseInt(now_hour%10)]);
            }));
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
            timer.stopTimer(clock_timer);
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }
