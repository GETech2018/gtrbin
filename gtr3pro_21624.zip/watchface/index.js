
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$sun$_$high$_$text_img = ''
        let normal$_$sun$_$low$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$analog_clock$_$time_pointer = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
        let idle$_$step$_$current$_$text_img = ''
        let idle$_$step$_$image_progress$_$img_level = ''
        let idle$_$heart_rate$_$text$_$text_img = ''
        let idle$_$heart_rate$_$image_progress$_$img_level = ''
        let idle$_$calorie$_$current$_$text_img = ''
        let idle$_$pai$_$weekly$_$text_img = ''
        let idle$_$distance$_$text$_$text_img = ''
        let idle$_$battery$_$text$_$text_img = ''
        let idle$_$battery$_$image_progress$_$img_level = ''
        let idle$_$sun$_$high$_$text_img = ''
        let idle$_$sun$_$low$_$text_img = ''
        let idle$_$weather$_$image_progress$_$img_level = ''
        let idle$_$temperature$_$current$_$text_img = ''
        let idle$_$date$_$img_date = ''
        let idle$_$week$_$week = ''
        let idle$_$analog_clock$_$time_pointer = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 114,
              hour_startY: 95,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 6,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 254,
              minute_startY: 95,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 6,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              second_zero: 1,
              second_startX: 388,
              second_startY: 144,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_space: 2,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 40,
              am_y: 118,
              am_en_path: '22.png',
              pm_x: 40,
              pm_y: 118,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 255,
              type: hmUI.data_type.STEP,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 263,
              image_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 379,
              type: hmUI.data_type.HEART,
              font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '54.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 337,
              image_array: ["55.png","56.png","57.png","58.png","59.png","60.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 308,
              type: hmUI.data_type.CAL,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 255,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 197,
              type: hmUI.data_type.DISTANCE,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '61.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 364,
              type: hmUI.data_type.BATTERY,
              font_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '72.png',//单位
              unit_tc: '72.png',//单位
              unit_en: '72.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 356,
              image_array: ["73.png","74.png","75.png","76.png","77.png","78.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 430,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '90.png', //小数点图片
              invalid_image: '89.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 430,
              type: hmUI.data_type.SUN_SET,
              font_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '92.png', //小数点图片
              invalid_image: '91.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 23,
              image_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '134.png',//单位
              unit_en: '135.png',//单位
              negative_image: '133.png', //负号图片
              invalid_image: '132.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 5,
              y: 131,
              src: '136.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 2,
              y: 255,
              src: '137.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 44,
              src: '138.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 369,
              month_startY: 210,
              month_sc_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_tc_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_en_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 316,
              day_startY: 204,
              day_sc_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_tc_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_en_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 237,
              y: 211,
              week_en: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              week_tc: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              week_sc: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 240,
              second_path: '158.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '159.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 114,
              hour_startY: 95,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 6,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 254,
              minute_startY: 95,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 6,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 40,
              am_y: 118,
              am_en_path: '22.png',
              pm_x: 40,
              pm_y: 118,
              pm_en_path: '23.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 255,
              type: hmUI.data_type.STEP,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 263,
              image_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 379,
              type: hmUI.data_type.HEART,
              font_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              invalid_image: '54.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 337,
              image_array: ["55.png","56.png","57.png","58.png","59.png","60.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 308,
              type: hmUI.data_type.CAL,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 255,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 197,
              type: hmUI.data_type.DISTANCE,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '61.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 364,
              type: hmUI.data_type.BATTERY,
              font_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '72.png',//单位
              unit_tc: '72.png',//单位
              unit_en: '72.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 356,
              image_array: ["73.png","74.png","75.png","76.png","77.png","78.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$sun$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 430,
              type: hmUI.data_type.SUN_RISE,
              font_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '90.png', //小数点图片
              invalid_image: '89.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$sun$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 430,
              type: hmUI.data_type.SUN_SET,
              font_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONAL_AOD,
              dot_image: '92.png', //小数点图片
              invalid_image: '91.png',// 无数据时显示的图片
              padding: true,
              isCharacter: false
            });
  
                    
            idle$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 23,
              image_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONAL_AOD,
              unit_sc: '134.png',//单位
              unit_en: '135.png',//单位
              negative_image: '133.png', //负号图片
              invalid_image: '132.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 369,
              month_startY: 210,
              month_sc_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_tc_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_en_array: ["139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 316,
              day_startY: 204,
              day_sc_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_tc_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_en_array: ["122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 237,
              y: 211,
              week_en: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              week_tc: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              week_sc: ["151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
                    
            idle$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              show_level: hmUI.show_level.ONAL_AOD,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  