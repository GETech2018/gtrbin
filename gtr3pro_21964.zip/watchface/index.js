﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_hour = ''
        let normal_digital_clock_minute = ''
        let normal_analog_clock_time_pointer_second = ''
		
        let hourArray = null
        let minuteArray = null
		let clock_timer = null


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
			
			hourArray = [
				"hours_0011_TWELVE.png",
                "hours_0000_ONE.png",
				"hours_0001_TWO.png",
				"hours_0002_THREE.png",
				"hours_0003_FOUR.png",
				"hours_0004_FIVE.png",
				"hours_0005_SIX.png",
				"hours_0006_SEVEN.png",
				"hours_0007_EIGHT.png",
				"hours_0008_NINE.png",
				"hours_0009_TEN.png",
				"hours_0010_ELEVEN.png"
            ]
			
			minuteArray = [
				"minutes_0000_ZERO.png",
				"minutes_0001_ONE.png",
				"minutes_0002_TWO.png",
				"minutes_0003_THREE.png",
				"minutes_0004_FOUR.png",
				"minutes_0005_FIVE.png",
				"minutes_0006_SIX.png",
				"minutes_0007_SEVEN.png",
				"minutes_0008_EIGHT.png",
				"minutes_0009_NINE.png",
				
				"minutes_0010_TEN.png",
				"minutes_0011_ELEVEN.png",
				"minutes_0012_TWELVE.png",
				"minutes_0013_THIRTEEN.png",
				"minutes_0014_FOURTEEN.png",
				"minutes_0015_FIFTEEN.png",
				"minutes_0016_SIXTEEN.png",
				"minutes_0017_SEVENTEEN.png",
				"minutes_0018_EIGHTEEN.png",
				"minutes_0019_NINETEEN.png",
				
				"minutes_0020_TWENTY-.png",
				"minutes_0021_TWENTY-ONE.png",
				"minutes_0022_TWENTY-TWO.png",
				"minutes_0023_TWENTY-THREE.png",
				"minutes_0024_TWENTY-FOUR.png",
				"minutes_0025_TWENTY-FIVE.png",
				"minutes_0026_TWENTY-SIX.png",
				"minutes_0027_TWENTY-SEVEN.png",
				"minutes_0028_TWENTY-EIGHT.png",
				"minutes_0029_TWENTY-NINE.png",
				
				"minutes_0030_THIRTY-.png",
				"minutes_0031_THIRTY-ONE.png",
				"minutes_0032_THIRTY-TWO.png",
				"minutes_0033_THIRTY-THREE.png",
				"minutes_0034_THIRTY-FOUR.png",
				"minutes_0035_THIRTY-FIVE.png",
				"minutes_0036_THIRTY-SIX.png",
				"minutes_0037_THIRTY-SEVEN.png",
				"minutes_0038_THIRTY-EIGHT.png",
				"minutes_0039_THIRTY-NINE.png",
				
				"minutes_0040_FOURTY-.png",
				"minutes_0041_FOURTY-ONE.png",
				"minutes_0042_FOURTY-TWO.png",
				"minutes_0043_FOURTY-THREE.png",
				"minutes_0044_FOURTY-FOUR.png",
				"minutes_0045_FOURTY-FIVE.png",
				"minutes_0046_FOURTY-SIX.png",
				"minutes_0047_FOURTY-SEVEN.png",
				"minutes_0048_FOURTY-EIGHT.png",
				"minutes_0049_FOURTY-NINE.png",
				
				"minutes_0050_FIFTY-.png",
				"minutes_0051_FIFTY-ONE.png",
				"minutes_0052_FIFTY-TWO.png",
				"minutes_0053_FIFTY-THREE.png",
				"minutes_0054_FIFTY-FOUR.png",
				"minutes_0055_FIFTY-FIVE.png",
				"minutes_0056_FIFTY-SIX.png",
				"minutes_0057_FIFTY-SEVEN.png",
				"minutes_0058_FIFTY-EIGHT.png",
				"minutes_0059_FIFTY-NINE.png",
            ]
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 106,
              font_array: ["weather_0000_0.png","weather_0001_1.png","weather_0002_2.png","weather_0003_3.png","weather_0004_4.png","weather_0005_5.png","weather_0006_6.png","weather_0007_7.png","weather_0008_8.png","weather_0009_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'weather_0011.png',
              unit_tc: 'weather_0011.png',
              unit_en: 'weather_0011.png',
              negative_image: 'weather_0010.png',
              invalid_image: 'weather_0012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 93,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 145,
              week_en: ["dow_0000_MONDAY.png","dow_0001_TUESDAY.png","dow_0002_WEDNESDAY.png","dow_0003_THURSDAY.png","dow_0004_FRIDAY.png","dow_0005_SATURDAY.png","dow_0006_SUNDAY.png"],
              week_tc: ["dow_0000_MONDAY.png","dow_0001_TUESDAY.png","dow_0002_WEDNESDAY.png","dow_0003_THURSDAY.png","dow_0004_FRIDAY.png","dow_0005_SATURDAY.png","dow_0006_SUNDAY.png"],
              week_sc: ["dow_0000_MONDAY.png","dow_0001_TUESDAY.png","dow_0002_WEDNESDAY.png","dow_0003_THURSDAY.png","dow_0004_FRIDAY.png","dow_0005_SATURDAY.png","dow_0006_SUNDAY.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 391,
              day_startY: 146,
              day_sc_array: ["date_0000_0.png","date_0001_1.png","date_0002_2.png","date_0003_3.png","date_0004_4.png","date_0005_5.png","date_0006_6.png","date_0007_7.png","date_0008_8.png","date_0009_9.png"],
              day_tc_array: ["date_0000_0.png","date_0001_1.png","date_0002_2.png","date_0003_3.png","date_0004_4.png","date_0005_5.png","date_0006_6.png","date_0007_7.png","date_0008_8.png","date_0009_9.png"],
              day_en_array: ["date_0000_0.png","date_0001_1.png","date_0002_2.png","date_0003_3.png","date_0004_4.png","date_0005_5.png","date_0006_6.png","date_0007_7.png","date_0008_8.png","date_0009_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 394,
              font_array: ["charge_0000_0.png","charge_0001_1.png","charge_0002_2.png","charge_0003_3.png","charge_0004_4.png","charge_0005_5.png","charge_0006_6.png","charge_0007_7.png","charge_0008_8.png","charge_0009_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 61,
              // start_y: 340,
              // color: 0xFF000000,
              // lenght: 196,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 338,
              font_array: ["steps_0000_0.png","steps_0001_1.png","steps_0002_2.png","steps_0003_3.png","steps_0004_4.png","steps_0005_5.png","steps_0006_6.png","steps_0007_7.png","steps_0008_8.png","steps_0009_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 61,
              // start_y: 317,
              // color: 0xFF000000,
              // lenght: 196,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 315,
              font_array: ["steps_0000_0.png","steps_0001_1.png","steps_0002_2.png","steps_0003_3.png","steps_0004_4.png","steps_0005_5.png","steps_0006_6.png","steps_0007_7.png","steps_0008_8.png","steps_0009_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 19,
              am_y: 181,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 19,
              pm_y: 181,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 58,
              y: 196,
              src: 'hours_0000_ONE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_minute = hmUI.createWidget(hmUI.widget.IMG, {
              x: 58,
              y: 256,
              src: 'minutes_0000_ZERO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 169,
              second_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const time_naw = hmSensor.createSensor(hmSensor.id.TIME);
				
			clock_timer = timer.createTimer(0, 1000, (function (option) {
				var hour = time_naw.hour;
				var minute = time_naw.minute;
				if (hour > 11) {hour = hour - 12};
				normal_digital_clock_hour.setProperty(hmUI.prop.SRC, hourArray[hour]);
				normal_digital_clock_minute.setProperty(hmUI.prop.SRC, minuteArray[minute]);
			}));


            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 180;
                let progressHeartRate = (valueHeartRate + 10)/(targetHeartRate + 10);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 257;
                  let start_y_normal_heart_rate = 340;
                  let lenght_ls_normal_heart_rate = -196;
                  let line_width_ls_normal_heart_rate = 10;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 257;
                  let start_y_normal_step = 317;
                  let lenght_ls_normal_step = -196;
                  let line_width_ls_normal_step = 10;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
				
				if (screenType != hmSetting.screen_type.AOD) {
					var hour = time_naw.hour;
					var minute = time_naw.minute;
					if (hour > 11) {hour = hour - 12};
					normal_digital_clock_hour.setProperty(hmUI.prop.SRC, hourArray[hour]);
					normal_digital_clock_minute.setProperty(hmUI.prop.SRC, minuteArray[minute]);
				};
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  