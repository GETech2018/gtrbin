﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'L1.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'L2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'L3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 101,
              y: 0,
              week_en: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png"],
              week_tc: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png"],
              week_sc: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -5,
              day_startY: 0,
              day_sc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              day_tc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              day_en_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              day_zero: 1,
              day_space: -440,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: -3,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -54,
              hour_startY: 0,
              hour_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              hour_zero: 1,
              hour_space: -401,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 54,
              minute_startY: 0,
              minute_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              minute_zero: 1,
              minute_space: -401,
              minute_follow: 0,
              minute_unit_en: 'H.png',
              minute_align: hmUI.align.RIGHT,

              second_startX: 162,
              second_startY: 0,
              second_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              second_zero: 1,
              second_space: -401,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -54,
              hour_startY: 0,
              hour_array: ["H.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              hour_zero: 0,
              hour_space: -401,
              hour_unit_sc: 'H.png',
              hour_unit_tc: 'H.png',
              hour_unit_en: 'H.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 54,
              minute_startY: 0,
              minute_array: ["H.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              minute_zero: 0,
              minute_space: -401,
              minute_follow: 0,
              minute_unit_en: 'H.png',
              minute_align: hmUI.align.RIGHT,

              second_startX: 162,
              second_startY: 0,
              second_array: ["H.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              second_zero: 0,
              second_space: -401,
              second_follow: 0,
              second_unit_en: 'H.png',
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  