﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_linear_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 328,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 359,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_fONT_13.png',
              unit_tc: 'SMALL_fONT_13.png',
              unit_en: 'SMALL_fONT_13.png',
              negative_image: 'SMALL_fONT_14.png',
              invalid_image: 'SMALL_fONT_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 359,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 359,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 329,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SMALL_fONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 263,
              src: 'system_bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 325,
              y: 273,
              src: 'system_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 266,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 90,
              // start_y: 107,
              // color: 0xFF0D0D0D,
              // lenght: 17,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'HAND_04.png',
              center_x: 99,
              center_y: 242,
              x: 13,
              y: 53,
              start_angle: 29,
              end_angle: 329,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 128,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'SMALL_fONT_11.png',
              unit_tc: 'SMALL_fONT_11.png',
              unit_en: 'SMALL_fONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 325,
              font_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 372,
              image_array: ["ZONE01.png","ZONE02.png","ZONE03.png","ZONE04.png","ZONE05.png","ZONE06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 95,
              day_sc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_tc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_en_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'HAND_05.png',
              center_x: 222,
              center_y: 112,
              posX: 21,
              posY: 39,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'HAND_05.png',
              center_x: 222,
              center_y: 112,
              posX: 21,
              posY: 78,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'HAND_04.png',
              center_x: 329,
              center_y: 113,
              x: 13,
              y: 53,
              start_angle: 106,
              end_angle: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 148,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 292,
              am_y: 193,
              am_sc_path: 'TIMES_AM.png',
              am_en_path: 'TIMES_AM.png',
              pm_x: 292,
              pm_y: 193,
              pm_sc_path: 'TIMES_PM.png',
              pm_en_path: 'TIMES_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 267,
              hour_startY: 210,
              hour_array: ["TIME_HM_fONT_01.png","TIME_HM_fONT_02.png","TIME_HM_fONT_03.png","TIME_HM_fONT_04.png","TIME_HM_fONT_05.png","TIME_HM_fONT_06.png","TIME_HM_fONT_07.png","TIME_HM_fONT_08.png","TIME_HM_fONT_09.png","TIME_HM_fONT_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 347,
              minute_startY: 210,
              minute_array: ["TIME_HM_fONT_01.png","TIME_HM_fONT_02.png","TIME_HM_fONT_03.png","TIME_HM_fONT_04.png","TIME_HM_fONT_05.png","TIME_HM_fONT_06.png","TIME_HM_fONT_07.png","TIME_HM_fONT_08.png","TIME_HM_fONT_09.png","TIME_HM_fONT_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 365,
              second_startY: 265,
              second_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 338,
              y: 216,
              src: 'TIME_HM_fONT_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HAND_01.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'HAND_02.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 19,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_03.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 20,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 199,
              w: 63,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 366,
              y: 264,
              w: 50,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 323,
              y: 264,
              w: 40,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 264,
              w: 48,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 359,
              w: 91,
              h: 24,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 324,
              w: 111,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 378,
              w: 85,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 324,
              w: 83,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 146,
              w: 116,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 328,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 359,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_fONT_13.png',
              unit_tc: 'SMALL_fONT_13.png',
              unit_en: 'SMALL_fONT_13.png',
              negative_image: 'SMALL_fONT_14.png',
              invalid_image: 'SMALL_fONT_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 359,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 359,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 329,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SMALL_fONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 263,
              src: 'system_bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 325,
              y: 273,
              src: 'system_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 266,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 90,
              // start_y: 107,
              // color: 0xFF0D0D0D,
              // lenght: 17,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'HAND_04.png',
              center_x: 99,
              center_y: 242,
              x: 13,
              y: 53,
              start_angle: 29,
              end_angle: 329,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 128,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'SMALL_fONT_11.png',
              unit_tc: 'SMALL_fONT_11.png',
              unit_en: 'SMALL_fONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 325,
              font_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 372,
              image_array: ["ZONE01.png","ZONE02.png","ZONE03.png","ZONE04.png","ZONE05.png","ZONE06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 95,
              day_sc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_tc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_en_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'HAND_05.png',
              center_x: 222,
              center_y: 112,
              posX: 21,
              posY: 39,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'HAND_05.png',
              center_x: 222,
              center_y: 112,
              posX: 21,
              posY: 78,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'HAND_04.png',
              center_x: 329,
              center_y: 113,
              x: 13,
              y: 53,
              start_angle: 106,
              end_angle: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 148,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 292,
              am_y: 193,
              am_sc_path: 'TIMES_AM.png',
              am_en_path: 'TIMES_AM.png',
              pm_x: 292,
              pm_y: 193,
              pm_sc_path: 'TIMES_PM.png',
              pm_en_path: 'TIMES_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 267,
              hour_startY: 210,
              hour_array: ["TIME_HM_fONT_01.png","TIME_HM_fONT_02.png","TIME_HM_fONT_03.png","TIME_HM_fONT_04.png","TIME_HM_fONT_05.png","TIME_HM_fONT_06.png","TIME_HM_fONT_07.png","TIME_HM_fONT_08.png","TIME_HM_fONT_09.png","TIME_HM_fONT_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 347,
              minute_startY: 210,
              minute_array: ["TIME_HM_fONT_01.png","TIME_HM_fONT_02.png","TIME_HM_fONT_03.png","TIME_HM_fONT_04.png","TIME_HM_fONT_05.png","TIME_HM_fONT_06.png","TIME_HM_fONT_07.png","TIME_HM_fONT_08.png","TIME_HM_fONT_09.png","TIME_HM_fONT_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 365,
              second_startY: 265,
              second_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 338,
              y: 216,
              src: 'TIME_HM_fONT_11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HAND_01.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'HAND_02.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 19,
              minute_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_03.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 20,
              second_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 90;
                  let start_y_normal_battery = 107;
                  let lenght_ls_normal_battery = 17;
                  let line_width_ls_normal_battery = 10;
                  let color_ls_normal_battery = 0xFF0D0D0D;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 90;
                  let start_y_idle_battery = 107;
                  let lenght_ls_idle_battery = 17;
                  let line_width_ls_idle_battery = 10;
                  let color_ls_idle_battery = 0xFF0D0D0D;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  