
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$pai$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$uvi$_$text$_$text_img = ''
        let normal$_$aqi$_$text$_$text_img = ''
        let normal$_$humidity$_$text$_$text_img = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 206,
              hour_startY: 219,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_follow: 1,
              second_zero: 1,
              second_startX: 414,
              second_startY: 308,
              second_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              second_space: 0,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 168,
              am_y: 66,
              am_sc_path: '23.png',
              am_en_path: '24.png',
              pm_x: 187,
              pm_y: 99,
              pm_sc_path: '25.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 74,
              day_startY: 194,
              day_sc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_tc_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_en_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 68,
              y: 244,
              week_en: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              week_tc: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              week_sc: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 71,
              type: hmUI.data_type.HEART,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '44.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 23,
              type: hmUI.data_type.STEP,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 441,
              type: hmUI.data_type.DISTANCE,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '55.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 393,
              type: hmUI.data_type.CAL,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 386,
              image_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 93,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 65,
              image_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 394,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '96.png',//单位
              invalid_image: '95.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 170,
              type: hmUI.data_type.BATTERY,
              font_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '97.png',//单位
              unit_tc: '97.png',//单位
              unit_en: '97.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 175,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let week = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              scale_x: 0,
              scale_y: 0,
              center_x: 127,
              center_y: 154,
              src: 'pointer.png',
              posX: 0,
              posY: 0,
              cover_x: 0,
              cover_y: 0,
              start_angle: 30, 
              end_angle: 180,
              type: hmUI.date.MONTH
            })
            
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 302,
              src: '108.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 293,
              y: 302,
              src: '109.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 302,
              src: '110.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$uvi$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 347,
              type: hmUI.data_type.UVI,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '111.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$aqi$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 347,
              type: hmUI.data_type.AQI,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '112.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$humidity$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 347,
              type: hmUI.data_type.HUMIDITY,
              font_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              align_h: hmUI.align.LEFT,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '114.png',//单位
              unit_tc: '114.png',//单位
              unit_en: '114.png',//单位
              invalid_image: '113.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 206,
              hour_startY: 219,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.CENTER_H,
              minute_zero: 1,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_follow: 1,
              am_x: 168,
              am_y: 66,
              am_sc_path: '23.png',
              am_en_path: '24.png',
              pm_x: 187,
              pm_y: 99,
              pm_sc_path: '25.png',
              pm_en_path: '26.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  