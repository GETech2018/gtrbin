﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
   
        const stepsArrayImg = new Array(5);
 		let debugText = null;
        const ASCIIARRAY = ["number_3.png","number_4.png","number_5.png","number_6.png","number_7.png","number_8.png","number_9.png","number_10.png","number_11.png","number_12.png"];


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 242,
              y: 15,
              image_array: ["cal_01.png","cal_02.png","cal_03.png","cal_04.png","cal_05.png","cal_06.png","cal_07.png","cal_08.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 319,
              image_array: ["goal_01.png","goal_02.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 103,
              font_array: ["power_001.png","power_002.png","power_003.png","power_004.png","power_005.png","power_006.png","power_007.png","power_008.png","power_009.png","power_010.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'power_000.png',
              unit_tc: 'power_000.png',
              unit_en: 'power_000.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 130,
              image_array: ["batt_icon_01.png","batt_icon_02.png","batt_icon_03.png","batt_icon_04.png","batt_icon_05.png","batt_icon_06.png","batt_icon_07.png","batt_icon_08.png","batt_icon_09.png","batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 281,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 333,
              font_array: ["021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather02.png',
              unit_tc: 'weather02.png',
              unit_en: 'weather02.png',
              negative_image: 'weather01.png',
              invalid_image: 'weather01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 319,
              y: 102,
              image_array: ["055.png","056.png","057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 114,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ERROR.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 114,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '009.png',
              center_x: 226,
              center_y: 120,
              x: 16,
              y: 60,
              start_angle: 287,
              end_angle: 449,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 151,
              font_array: ["031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 190,
              am_y: 288,
              am_sc_path: 'system_AM.png',
              am_en_path: 'system_AM.png',
              pm_x: 190,
              pm_y: 288,
              pm_sc_path: 'system_PM.png',
              pm_en_path: 'system_PM.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 302,
              hour_startY: 216,
              hour_array: ["011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 359,
              minute_startY: 216,
              minute_array: ["021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 219,
              src: '010.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '008.png',
              center_x: 227,
              center_y: 333,
              posX: 16,
              posY: 49,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 173,
              week_en: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_tc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              week_sc: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png"],
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 117,
              day_startY: 213,
              day_sc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_tc_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_en_array: ["041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 327,
              y: 172,
              src: '054.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 220,
              src: '053.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '088.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 28,
              hour_posY: 190,
              show_level: hmUI.show_level.ALL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '087.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 28,
              minute_posY: 190,
              show_level: hmUI.show_level.ALL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '086.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 190,
              show_level: hmUI.show_level.ALL,
            });

 		stepsArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 209,
				pos_y: 40,
				center_x: 228,
				center_y: 228,
				angle: 260,
				src: 'number_3.png',
				show_level: hmUI.show_level.ALL,
			});
			
			stepsArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 214,
				pos_y: 40,
				center_x: 228,
				center_y: 228,
				angle: 266,
				src: 'number_4.png',
				show_level: hmUI.show_level.ALL,
			});
			
			stepsArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 219,
				pos_y: 40,
				center_x: 228,
				center_y: 228,
				angle: 272,
				src: 'number_5.png',
				show_level: hmUI.show_level.ALL,
			});
			
			stepsArrayImg[3] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 224,
				pos_y: 40,
				center_x: 228,
				center_y: 228,
				angle: 278,
				src: 'number_6.png',
				show_level: hmUI.show_level.ALL,
			});
			
			stepsArrayImg[4] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 454,
				h: 454,
				pos_x: 229,
				pos_y: 40,
				center_x: 228,
				center_y: 228,
				angle: 284,
				src: 'number_7.png',
				show_level: hmUI.show_level.ALL,
			});
			
			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 0,
				w: 95,
				h: 23,
				text_size: 24,
				char_space: 2, //межсимвольный интервал
				//text_style: hmUI.text_style.CHAR_WRAP,
				//text: "Test",
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});

			var step = hmSensor.createSensor(hmSensor.id.STEP);			
			var stepCurrent=step.current;			
			debugText.setProperty(hmUI.prop.TEXT, String(step.current));
			let stepString = String(step.current);			
            let index = 0;
			for (var i = 1; i < 5; i++) {
				stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
			}				
			for (let char of stepString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 5) {
					break;
				}
				stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}
           
	
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                   console.log('ui resume');
                   
				   console.log('ui resume');
				   var stepCurrent=step.current;
				   
					//stepString=String(stepCurrent);
					
					debugText.setProperty(hmUI.prop.TEXT, String(stepCurrent));
					index = 0;
					for (var i = 1; i < 5; i++) {
						stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					}
					for (let char of String(stepCurrent)) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 5) {
							break;
						}
						stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
					
					dateDay = date.day;
					dateString = String(date.day);
					debugText.setProperty(hmUI.prop.TEXT, String(dateString));
					
					index = 0;
					//for (var i = 1; i < 5; i++) {
					//	dateArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
					//}
					dateArrayImg[0].setProperty(hmUI.prop.SRC, 'number_3.png');
					if (dateDay < 10) {
						index = 1;
					}
						
					for (let char of dateString) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 2) {
							break;
						}
						
					debugText.setProperty(hmUI.prop.TEXT, String(index));
						dateArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
					
                }),
            });












            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 199,
              w: 63,
              h: 53,
              src: 'goal_01.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ALL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 358,
              y: 211,
              w: 49,
              h: 34,
              src: 'goal_01.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ALL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 208,
              w: 33,
              h: 39,
              src: 'goal_01.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 268,
              w: 59,
              h: 49,
              src: 'goal_01.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 93,
              w: 74,
              h: 63,
              src: 'goal_01.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 106,
              w: 43,
              h: 39,
              src: 'goal_01.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 108,
              w: 45,
              h: 41,
              src: 'goal_01.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 143,
              w: 42,
              h: 44,
              src: 'goal_01.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 298,
              w: 61,
              h: 58,
              src: 'goal_01.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  