﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BACK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 174,
              font_array: ["TEMP_0.png","TEMP_1.png","TEMP_2.png","TEMP_3.png","TEMP_4.png","TEMP_5.png","TEMP_6.png","TEMP_7.png","TEMP_8.png","TEMP_9.png"],
              padding: false,
              h_space: -2,
              negative_image: 'TEMP_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 336,
              font_array: ["Puls_0.png","Puls_1.png","Puls_2.png","Puls_3.png","Puls_4.png","Puls_5.png","Puls_6.png","Puls_7.png","Puls_8.png","Puls_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 173,
              image_array: ["Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 93,
              y: 190,
              src: 'Alarm_0.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 248,
              month_startY: 174,
              month_sc_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              month_tc_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              month_en_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 174,
              day_sc_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              day_tc_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              day_en_array: ["DATE_0.png","DATE_1.png","DATE_2.png","DATE_3.png","DATE_4.png","DATE_5.png","DATE_6.png","DATE_7.png","DATE_8.png","DATE_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 183,
              y: 218,
              week_en: ["DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png"],
              week_tc: ["DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png"],
              week_sc: ["DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 234,
              hour_array: ["BIG_0.png","BIG_1.png","BIG_2.png","BIG_3.png","BIG_4.png","BIG_5.png","BIG_6.png","BIG_7.png","BIG_8.png","BIG_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.LEFT,

              minute_startX: 178,
              minute_startY: 234,
              minute_array: ["BIG_0.png","BIG_1.png","BIG_2.png","BIG_3.png","BIG_4.png","BIG_5.png","BIG_6.png","BIG_7.png","BIG_8.png","BIG_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 249,
              second_startY: 248,
              second_array: ["SEC_0.png","SEC_1.png","SEC_2.png","SEC_3.png","SEC_4.png","SEC_5.png","SEC_6.png","SEC_7.png","SEC_8.png","SEC_9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  