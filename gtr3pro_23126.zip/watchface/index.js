﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Casio_aqs800w.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 224,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 382,
              y: 363,
              src: 'BAT9001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 334,
              image_array: ["Bat0000.png","Bat0001.png","Bat0002.png","Bat0003.png","Bat0004.png","Bat0005.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 349,
              day_sc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_tc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_en_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 349,
              week_en: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              week_tc: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              week_sc: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Acs001.png',
              hour_centerX: 237,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 123,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Acs002.png',
              minute_centerX: 237,
              minute_centerY: 240,
              minute_posX: 50,
              minute_posY: 184,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Casio_aqs800w.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 224,
              src: '24.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 382,
              y: 363,
              src: 'BAT9001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 334,
              image_array: ["Bat0000.png","Bat0001.png","Bat0002.png","Bat0003.png","Bat0004.png","Bat0005.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 349,
              day_sc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_tc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_en_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 349,
              week_en: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              week_tc: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              week_sc: ["CsW001.png","CsW002.png","CsW003.png","CsW004.png","CsW005.png","CsW006.png","CsW007.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Acs001.png',
              hour_centerX: 237,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 123,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Acs002.png',
              minute_centerX: 237,
              minute_centerY: 240,
              minute_posX: 50,
              minute_posY: 184,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  