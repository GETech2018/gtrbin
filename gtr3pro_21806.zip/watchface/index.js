
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$analog_clock$_$time_pointer = ''



        let normal_cal_circle_scale = ''
        let normal_battery_circle_scale = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ALL,
            });
            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 355,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 80,
              // line_width: 5,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ALL,
            // });

            let screenTypeC = hmSetting.getScreenType();
            if (screenTypeC != hmSetting.screen_type.AOD) {
              normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };



            const widgetDelegateC = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                console.log('ui resume');
                
                const cal = hmSensor.createSensor(hmSensor.id.CALORIE);
                let valueCal = cal.current;
                let targetCal = cal.target;
                let progressCal = valueCal/targetCal;
                if (progressCal > 1) progressCal = 1;
                let progress_cs_normal_cal = progressCal;

                if (screenTypeC != hmSetting.screen_type.AOD) {

                // normal_cal_circle_scale
                  // initial parameters
                  let start_angle_normal_cal = -90;
                  let end_angle_normal_cal = 270;
                  let center_x_normal_cal = 355;
                  let center_y_normal_cal = 240;
                  let radius_normal_cal = 85;
                  let line_width_cs_normal_cal = 5;
                  let color_cs_normal_cal = 0xFFFF0000;
                  
                  // calculated parameters
                  let arcX_normal_cal = center_x_normal_cal - radius_normal_cal;
                  let arcY_normal_cal = center_y_normal_cal - radius_normal_cal;
                  let CircleWidth_normal_cal = 2 * radius_normal_cal;
                  let angle_offset_normal_cal = end_angle_normal_cal - start_angle_normal_cal;
                  angle_offset_normal_cal = angle_offset_normal_cal * progress_cs_normal_cal;
                  let end_angle_normal_cal_draw = start_angle_normal_cal + angle_offset_normal_cal;
                  
                normal_cal_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_cal,
                    y: arcY_normal_cal,
                    w: CircleWidth_normal_cal,
                    h: CircleWidth_normal_cal,
                    start_angle: start_angle_normal_cal,
                    end_angle: end_angle_normal_cal_draw,
                    color: color_cs_normal_cal,
                    line_width: line_width_cs_normal_cal,
                  });
                };

              }),
            });


            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 127,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 82,
              // line_width: 5,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ALL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

                console.log('ui resume');
                
                const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
                let valueBattery = battery.current;

                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 127;
                  let center_y_normal_battery = 240;
                  let radius_normal_battery = 88;
                  let line_width_cs_normal_battery = 5;
                  let color_cs_normal_battery = 0xFFFF0000;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              }),
            });





                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 61,
              hour_startY: 188,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 293,
              minute_startY: 188,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 0,
              minute_align: hmUI.align.LEFT,
              minute_follow: 0,
              am_x: 395,
              am_y: 342,
              am_en_path: '12.png',
              pm_x: 395,
              pm_y: 342,
              pm_en_path: '13.png',
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 279,
              type: hmUI.data_type.CAL,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 379,
              type: hmUI.data_type.HEART,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: -2,
              show_level: hmUI.show_level.ALL,
              invalid_image: '34.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 380,
              type: hmUI.data_type.STEP,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: -2,
              show_level: hmUI.show_level.ALL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 112,
              y: 344,
              image_array: ["35.png","36.png","37.png","38.png","39.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 307,
              month_startY: 94,
              month_sc_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              month_tc_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              month_en_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 211,
              day_startY: 69,
              day_sc_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              day_tc_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              day_en_array: ["52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: -16,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 94,
              week_en: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              week_tc: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              week_sc: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              show_level: hmUI.show_level.ALL,
            });
  
                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 143,
              image_array: ["69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 380,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              unit_sc: '100.png',//单位
              unit_en: '101.png',//单位
              negative_image: '99.png', //负号图片
              invalid_image: '98.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 34,
              src: '102.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 67,
              src: '103.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ALL,
            });

            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 65,
              src: '109.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 296,
              y: 37,
              src: '104.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 284,
              type: hmUI.data_type.BATTERY,
              font_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ALL,
              unit_sc: '105.png',//单位
              unit_tc: '105.png',//单位
              unit_en: '105.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 125,
              hour_centerY: 238,
              hour_posX: 103,
             hour_posY: 112,
              hour_path: '106.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 355,
              minute_centerY: 238,
              minute_posX: 103,
             minute_posY: 112,
              minute_path: '107.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
             second_posY: 236,
              second_path: '108.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ALL,
            });
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  