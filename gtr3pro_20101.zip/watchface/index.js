    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
		let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
		let normal$_$battery$_$text$_$text_img = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''		
		let idle$_$digital_clock$_$img_time = ''		
		
		
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                  
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 115,
              hour_startY: 260,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 250,
              minute_startY: 260,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 4,
              minute_align: hmUI.align.RIGHT,
              minute_follow: 0,
/*            second_zero: 1,
              second_startX: 393,
              second_startY: 250,
              second_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              second_space: 3,
              second_align: hmUI.align.LEFT,
              second_follow: 0,
              am_x: 393,
              am_y: 194,
              am_en_path: '32.png',
              pm_x: 393,
              pm_y: 194,
              pm_en_path: '33.png',
 */             
			  show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 196,
              week_en: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              week_tc: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              week_sc: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
			  week_align: hmUI.align.RIGHT,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			  
            });
  
                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 196,
              month_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 225,
              day_startY: 196,
              day_sc_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              day_tc_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              day_en_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              day_align: hmUI.align.CENTER_H,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 418,
              type: hmUI.data_type.BATTERY,
              font_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  unit_sc: '14.png',
              unit_tc: '14.png',
              unit_en: '14.png',
              padding: false,
              isCharacter: false
            });
               
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 195,
              type: hmUI.data_type.STEP,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 185,
              type: hmUI.data_type.DISTANCE,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '91.png',
              unit_tc: '91.png',
              unit_en: '91.png',
              dot_image: '90.png',
              padding: false,
              isCharacter: false
            });
                      
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 125,
              type: hmUI.data_type.HEART,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '16.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 125,
              type: hmUI.data_type.CAL,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              align_h: hmUI.align.LEFT,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });

                 
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 260,
              image_array: ["61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 320,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '13.png',//单位
              unit_en: '13.png',//单位
              negative_image: '18.png', //负号图片
              invalid_image: '16.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
                      
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 301,
              src: '20.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                   

            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 296,
              y: 366,
              src: '12.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
			   });
                   
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 366,
              src: '19.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 115,
              hour_startY: 260,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_space: 4,
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_startX: 250,
              minute_startY: 260,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_space: 4,
              minute_align: hmUI.align.RIGHT,
              minute_follow: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  